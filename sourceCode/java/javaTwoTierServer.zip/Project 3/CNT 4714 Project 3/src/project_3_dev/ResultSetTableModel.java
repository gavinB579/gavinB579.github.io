/*
Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title: Project 3 – A Two-tier Client-Server Application
Date: October 26, 2025
Class: 0001
*/


package project_3_dev;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import com.mysql.cj.jdbc.MysqlDataSource;

public class ResultSetTableModel extends AbstractTableModel
{
	private Connection connection;
	private Statement statement;
	private ResultSet resultSet;
	private ResultSetMetaData metaData;
	private int numberOfRows;
	
	private boolean connectedToDatabase = false;
	
	MysqlDataSource dataSource = null;
	Properties properties = null;
	
	//Resets the variables to be used for the first time or again. Also throws exception if they try to execute something without being connected.
	public ResultSetTableModel(Connection connect, String query) throws SQLException, ClassNotFoundException
	{
		if (connect == null)
		{
			throw new SQLException("Not connected to Database");
		}
		connection = connect;
		statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);	
		resultSet = null;
		metaData = null;
		numberOfRows = 0;
		connectedToDatabase = true;
	}
	/*****************************************************************************************
	 ****************************************************************************************/		
	
	
	
	/*****************************************************************************************
	 * This chunk of methods handle getting the rowCount, columnCount, columnName, and columnClass
	 ****************************************************************************************/
	//Gets number of rows for JTable formatting.
	public int getRowCount() throws IllegalStateException
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		return numberOfRows;
	}
	
	//Gets number of columns for JTable formatting.
	public int getColumnCount() throws IllegalStateException
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		try
		{
			return metaData.getColumnCount();
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
		}
		return 0;
	}
	
	//Gets the class of the column.
	public Class getColumnClass(int column) throws IllegalStateException 
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		try
		{
			String className = metaData.getColumnClassName(column + 1);
			return Class.forName(className);
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}

		return Object.class;
	}
	
	//Gets the name of the column.
	public String getColumnName(int column) throws IllegalStateException
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		try
		{
			return metaData.getColumnName(column + 1);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
		}
		return "";
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	/*****************************************************************************************
	 * Gets the value at a specific row/column.
	 ****************************************************************************************/
	public Object getValueAt(int row, int column) throws IllegalStateException
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		try
		{
			resultSet.next();
			resultSet.absolute(row + 1);
			return resultSet.getObject(column + 1);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
		}
		return "";
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	/*****************************************************************************************
	 * This chunk of methods handle the setQuery and setUpdate methods.
	 ****************************************************************************************/
	public void setQuery(String query) throws SQLException, IllegalStateException
	{
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		resultSet = statement.executeQuery(query);
		
		metaData = resultSet.getMetaData();
		
		resultSet.last();
		numberOfRows = resultSet.getRow();
		
		//Stops the accountant from being logged.
		if (!connection.getMetaData().getUserName().equals("theaccountant@localhost"))
		{
			//Sends query to indicate that the query counter needs to increment.
			String queryOrUpdate = "query";
			operationsLog(queryOrUpdate);
		}
	}	

	public int setUpdate(String query) throws SQLException, IllegalStateException
	{
		int res;
		if(connectedToDatabase != true)
		{
			throw new IllegalStateException("Not connected to Database");
		}
		res = statement.executeUpdate(query);
		
		//Stops the accountant from being logged.
		if (!connection.getMetaData().getUserName().equals("theaccountant@localhost"))
		{
			//Sends update to indicate that the update counter needs to increment.
			String queryOrUpdate = "update";
			operationsLog(queryOrUpdate);
		}
		
		return res;
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	/*****************************************************************************************
	 * This chunk of methods handle the setQuery and setUpdate methods.
	 ****************************************************************************************/
	public void operationsLog(String queryOrUpdate) throws SQLException, IllegalStateException
	{
		FileInputStream fileData;
		
		properties = new Properties();
		
		
		//Variables for preparedstatements.
		String findUser = "select * from operationscount where login_username = ?;";
		String insertUser = "insert into operationscount (login_username, num_queries, num_updates) values (?, 1, 0);";
		String updateNumQueries = "update operationscount set num_queries = num_queries + 1 where login_username = ?;";
		String updateNumUpdates = "update operationscount set num_updates = num_updates + 1 where login_username = ?;";
		
		//Handles returns of .executeUpdates.
		int result = 0;
		
		try
		{
			//Gets the username and password of file named project3app.properties.
			fileData = new FileInputStream("project3app.properties");
			properties.load(fileData);
			String propertiesUsername = properties.getProperty("MYSQL_DB_USERNAME");
			String propertiesPassword = properties.getProperty("MYSQL_DB_PASSWORD");
			
			//Gets the url of operationslog.properties.
			fileData = new FileInputStream("operationslog.properties");
			properties.load(fileData);
			String propertiesURL = properties.getProperty("MYSQL_DB_URL");
		
			//Creates new connection between project3app and operationslog.
			dataSource = new MysqlDataSource();
			dataSource.setURL(propertiesURL);
			dataSource.setUser(propertiesUsername);
			dataSource.setPassword(propertiesPassword);
			
			//Gets the metadata of the connection the user chose (NOT THE LOGGING CONNECTION)
			String username = connection.getMetaData().getUserName();
			
			//Creates new connection specifically for logging data.
			Connection loggingConnection = dataSource.getConnection();
			
			//Prepared statements. The setString replaces the "?" which the applicable replacement, username in this case
			PreparedStatement prepStmtFindUser = loggingConnection.prepareStatement(findUser);
			prepStmtFindUser.setString(1, username);
			PreparedStatement prepStmtInsertUser = loggingConnection.prepareStatement(insertUser);
			prepStmtInsertUser.setString(1, username);
			PreparedStatement prepStmtUpdateNumQueries = loggingConnection.prepareStatement(updateNumQueries);
			prepStmtUpdateNumQueries.setString(1, username);
			PreparedStatement prepStmtUpdateNumUpdates = loggingConnection.prepareStatement(updateNumUpdates);
			prepStmtUpdateNumUpdates.setString(1, username);
			
			
			//Loops through existing logs to see if the user being logged already exists.
			ResultSet loggingResultSet = prepStmtFindUser.executeQuery();
			while(loggingResultSet.next())
			{
				//If user matches an existing entry, result gets updated and the desired update/query increments.
				if(username.equals(loggingResultSet.getString("login_username")))
				{
					//If this function got sent query, it means the data being logged is a query.
					if(queryOrUpdate.equals("query"))
					{
						result = prepStmtUpdateNumQueries.executeUpdate();
					}
					//Else it must be an update.
					else
					{
						result = prepStmtUpdateNumUpdates.executeUpdate();
					}
					//Loop breaks. User was found, not need to keep searching.
					break;
				}
			}
			//If result is 0, that means no existing match was found for user, and a new one must be made.
			if (result == 0)
			{
				//New user entry created.
				result = prepStmtInsertUser.executeUpdate();
				//If this function got sent query, it means the data being logged is a query.
				if(queryOrUpdate.equals("query"))
				{
					result = prepStmtUpdateNumQueries.executeUpdate();
				}
				//Else it must be an update.
				else
				{
					result = prepStmtUpdateNumUpdates.executeUpdate();
				}
			}
			//The logging connection must be closed, as it is not longer being utilized.
			loggingConnection.close();
		}
		catch(IOException e)
		{
			JOptionPane.showMessageDialog(null, e.getMessage(), "OPERATIONS LOG ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}
}
