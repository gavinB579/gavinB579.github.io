/*
Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title: Project 3 – A Two-tier Client-Server Application
Date: October 26, 2025
Class: 0001
*/


package project_3_dev;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class styleComponents_Accountant 
{
	private static final int BUTTON_LENGTH = 275;
	private static final int BUTTON_HEIGHT = 40;
	
	private static final int TEXTBOX_LENGTH = 300;
	private static final int TEXTBOX_HEIGHT = 42;
	
	private static final int HEADER_LENGTH = 1200;
	private static final int HEADER_HEIGHT = 42;
	
	private static final int BORDER_LENGTH = 275;
	private static final int BORDER_HEIGHT = 40;
	
	
	public static void styling(Project_3_Final_Accountant gui)
	{
		Font headerFont = new Font("Times New Roman", Font.BOLD, 26);
		Font buttonFont = new Font("Times New Roman", Font.BOLD, 20);
		Font labelFont = new Font("Times New Roman", Font.PLAIN, 26);
		Font textAreaFont = new Font("Arial", Font.BOLD, 22);
		Font tableFont = new Font("Arial", Font.PLAIN, 16);
		

		Dimension dropdownSize = new Dimension(300, 42);
		Dimension textfieldSize = new Dimension(TEXTBOX_LENGTH, TEXTBOX_HEIGHT);
		Dimension buttonSize = new Dimension(BUTTON_LENGTH, BUTTON_HEIGHT);
		Dimension headerSize = new Dimension(HEADER_LENGTH, HEADER_HEIGHT);
		Dimension borderSize = new Dimension(BORDER_LENGTH, BORDER_HEIGHT);
		
		
		Border labelBorder = BorderFactory.createLineBorder(Color.black, 1);
		
		
		gui.databaseURLPropertiesLabel = new JLabel("DB URL Properties");
		gui.databaseURLPropertiesLabel.setBorder(labelBorder);
		gui.databaseURLPropertiesLabel.setBackground(Color.lightGray);
		gui.databaseURLPropertiesLabel.setOpaque(true);
		gui.databaseURLPropertiesLabel.setFont(labelFont);
		gui.databaseURLPropertiesLabel.setPreferredSize(borderSize);
		gui.databaseURLPropertiesLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		gui.userPropertiesLabel = new JLabel("User Properties");
		gui.userPropertiesLabel.setBorder(labelBorder);
		gui.userPropertiesLabel.setBackground(Color.lightGray);
		gui.userPropertiesLabel.setOpaque(true);
		gui.userPropertiesLabel.setFont(labelFont);
		gui.userPropertiesLabel.setPreferredSize(borderSize);
		gui.userPropertiesLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		gui.usernameLabel = new JLabel("Username");
		gui.usernameLabel.setBorder(labelBorder);
		gui.usernameLabel.setBackground(Color.lightGray);
		gui.usernameLabel.setOpaque(true);
		gui.usernameLabel.setFont(labelFont);
		gui.usernameLabel.setPreferredSize(borderSize);
		gui.usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		gui.passwordLabel = new JLabel("Password");
		gui.passwordLabel.setBorder(labelBorder);
		gui.passwordLabel.setBackground(Color.lightGray);
		gui.passwordLabel.setOpaque(true);
		gui.passwordLabel.setFont(labelFont);
		gui.passwordLabel.setPreferredSize(borderSize);
		gui.passwordLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		gui.connectionDetailsLabel = new JLabel("Connection Details");
		gui.connectionDetailsLabel.setFont(headerFont);
		gui.connectionDetailsLabel.setForeground(Color.blue);
		
		gui.sqlCommandLabel = new JLabel("Enter an SQL Command                                              ");
		gui.sqlCommandLabel.setFont(headerFont);
		gui.sqlCommandLabel.setForeground(Color.blue);
		
		gui.sqlExecutionWindowLabel = new JLabel("SQL Execution Result Window                                                                                                                         ");
		gui.sqlExecutionWindowLabel.setFont(headerFont);
		gui.sqlExecutionWindowLabel.setForeground(Color.blue);
		
		
		gui.connectionStatusHeader = new JLabel("NO CONNECTION ESTABLISHED");
		gui.connectionStatusHeader.setFont(headerFont);
		gui.connectionStatusHeader.setBorder(labelBorder);
		gui.connectionStatusHeader.setBackground(Color.red);
		gui.connectionStatusHeader.setOpaque(true);
		gui.connectionStatusHeader.setMinimumSize(headerSize);
		gui.connectionStatusHeader.setMaximumSize(headerSize);
		gui.connectionStatusHeader.setPreferredSize(headerSize);
		
		
		gui.sqlCommandTextArea = new JTextArea(10,32);
		gui.sqlCommandTextArea.setEditable(true);
		gui.sqlCommandTextArea.setLineWrap(true);
		gui.sqlCommandTextArea.setBorder(labelBorder);
		gui.sqlCommandTextArea.setBackground(Color.white);
		gui.sqlCommandTextArea.setOpaque(true);
		gui.sqlCommandTextArea.setFont(textAreaFont);
		
		
		gui.sqlResultTable = new JTable(gui.tableModel);
		gui.sqlResultTable.setBorder(labelBorder);
		gui.sqlResultTable.setBackground(Color.white);
		gui.sqlResultTable.setOpaque(true);
		gui.sqlResultTable.setFont(tableFont);
		gui.sqlResultTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		gui.sqlResultTable.setEnabled(false);
		gui.sqlResultTable.setFont(tableFont);
		
		
		gui.usernameTextfield = new JTextField();
		gui.usernameTextfield.setEditable(true);
		gui.usernameTextfield.setFont(textAreaFont);
		gui.usernameTextfield.setBackground(Color.black);
		gui.usernameTextfield.setForeground(Color.white);
		gui.usernameTextfield.setBorder(labelBorder);
		gui.usernameTextfield.setMinimumSize(textfieldSize);
		gui.usernameTextfield.setMaximumSize(textfieldSize);
		gui.usernameTextfield.setPreferredSize(textfieldSize);
		
		
		gui.passwordField = new JPasswordField();
		gui.passwordField.setEditable(true);
		gui.passwordField.setFont(textAreaFont);
		gui.passwordField.setBackground(Color.black);
		gui.passwordField.setForeground(Color.white);
		gui.passwordField.setBorder(labelBorder);
		gui.passwordField.setMinimumSize(textfieldSize);
		gui.passwordField.setMaximumSize(textfieldSize);
		gui.passwordField.setPreferredSize(textfieldSize);
		
		
		gui.databaseURLPropertiesTextField = new JTextField("operationslog.properties");
		gui.databaseURLPropertiesTextField.setEditable(false);
		gui.databaseURLPropertiesTextField.setMinimumSize(dropdownSize);
		gui.databaseURLPropertiesTextField.setMaximumSize(dropdownSize);
		gui.databaseURLPropertiesTextField.setPreferredSize(dropdownSize);
		gui.databaseURLPropertiesTextField.setBackground(Color.white);
		gui.databaseURLPropertiesTextField.setBorder(labelBorder);
		gui.databaseURLPropertiesTextField.setFont(textAreaFont);
		
		gui.userPropertiesTextField = new JTextField("theaccountant.properties");
		gui.userPropertiesTextField.setEditable(false);
		gui.userPropertiesTextField.setMinimumSize(dropdownSize);
		gui.userPropertiesTextField.setMaximumSize(dropdownSize);
		gui.userPropertiesTextField.setPreferredSize(dropdownSize);
		gui.userPropertiesTextField.setBackground(Color.white);
		gui.userPropertiesTextField.setBorder(labelBorder);
		gui.userPropertiesTextField.setFont(textAreaFont);
				
		
		gui.connectToDatabaseButton = new JButton("Connect to Database");
		gui.connectToDatabaseButton.setBackground(Color.blue);
		gui.connectToDatabaseButton.setForeground(Color.white);
		gui.connectToDatabaseButton.setFont(buttonFont);
		gui.connectToDatabaseButton.setMinimumSize(buttonSize);
		gui.connectToDatabaseButton.setMaximumSize(buttonSize);
		gui.connectToDatabaseButton.setPreferredSize(buttonSize);
		gui.connectToDatabaseButton.setEnabled(true);
		
		gui.disconnectFromDatabaseButton = new JButton("Disconnect From Database");
		gui.disconnectFromDatabaseButton.setBackground(Color.red);
		gui.disconnectFromDatabaseButton.setFont(buttonFont);
		gui.disconnectFromDatabaseButton.setMinimumSize(buttonSize);
		gui.disconnectFromDatabaseButton.setMaximumSize(buttonSize);
		gui.disconnectFromDatabaseButton.setPreferredSize(buttonSize);
		gui.disconnectFromDatabaseButton.setEnabled(true);
		
		gui.clearSQLCommandButton = new JButton("Clear SQL Command");
		gui.clearSQLCommandButton.setBackground(Color.yellow);
		gui.clearSQLCommandButton.setFont(buttonFont);
		gui.clearSQLCommandButton.setMinimumSize(buttonSize);
		gui.clearSQLCommandButton.setMaximumSize(buttonSize);
		gui.clearSQLCommandButton.setPreferredSize(buttonSize);
		gui.clearSQLCommandButton.setEnabled(true);
		
		gui.executeSQLCommandButton = new JButton("Execute SQL Command");
		gui.executeSQLCommandButton.setBackground(Color.green);
		gui.executeSQLCommandButton.setFont(buttonFont);
		gui.executeSQLCommandButton.setMinimumSize(buttonSize);
		gui.executeSQLCommandButton.setMaximumSize(buttonSize);
		gui.executeSQLCommandButton.setPreferredSize(buttonSize);
		gui.executeSQLCommandButton.setEnabled(true);
		
		gui.clearResultWindowButton = new JButton("Clear Result Window");
		gui.clearResultWindowButton.setBackground(Color.yellow);
		gui.clearResultWindowButton.setFont(buttonFont);
		gui.clearResultWindowButton.setMinimumSize(buttonSize);
		gui.clearResultWindowButton.setMaximumSize(buttonSize);
		gui.clearResultWindowButton.setPreferredSize(buttonSize);
		gui.clearResultWindowButton.setEnabled(true);
		
		gui.closeApplicationButton = new JButton("Close Application");
		gui.closeApplicationButton.setBackground(Color.red);
		gui.closeApplicationButton.setFont(buttonFont);
		gui.closeApplicationButton.setMinimumSize(buttonSize);
		gui.closeApplicationButton.setMaximumSize(buttonSize);
		gui.closeApplicationButton.setPreferredSize(buttonSize);
		gui.closeApplicationButton.setEnabled(true);
		
	}
}
