/*
Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title: Project 3 – A Two-tier Client-Server Application
Date: October 26, 2025
Class: 0001
*/

package project_3_dev;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.Properties;


public class Project_3_Final extends JFrame
{
	private JPanel topPanel, bottomPanel, leftPanel, rightPanel;
	
	
	public JButton connectToDatabaseButton, disconnectFromDatabaseButton, clearSQLCommandButton, executeSQLCommandButton, clearResultWindowButton, closeApplicationButton;
	public JLabel databaseURLPropertiesLabel, userPropertiesLabel, usernameLabel, passwordLabel, connectionStatusHeader, connectionDetailsLabel, sqlCommandLabel, sqlExecutionWindowLabel;
	public JTextArea sqlCommandTextArea; 
	public ResultSetTableModel tableModel;
	public JTable sqlResultTable;
	public JTextField usernameTextfield;
	public JPasswordField passwordField;
	public JComboBox<String> databaseURLPropertiesDropdown, userPropertiesDropdown;

	
	
	private connectButtonHandler connectDatabaseHandler;
	private disconnectButtonHandler disconnectDatabaseHandler;
	private clearCommandButtonHandler clearSQLCommandHandler;
	private executeCommandButtonHandler executeCommandHandler;
	private clearResultButtonHandler clearResultHander;
	private closeButtonHandler closeApplicationHandler;
	
	
	String[] databaseURLPropertiesDropdownOptions = {"project3.properties", "bikedb.properties"};
	String[] userPropertiesDropdownOptions = {"root.properties", "client1.properties", "client2.properties"};
	
	
	Connection connection = null;
	FileInputStream fileData = null;
	MysqlDataSource dataSource = null;
	
	
	public static Properties properties;
	
	
	private static final int LENGTH = 1300;
	private static final int HEIGHT = 900;
	
	
	public Project_3_Final()
	{
		setTitle("SQL CLIENT APPLICATION - (GB - CNT 4714 - FALL 2025 - PROJECT 3)");
		setSize(LENGTH, HEIGHT);
		
		
		//Calls the styling and handlers. The styling call handles the styling for every component, be it labels, buttons, etc.
		styleComponents.styling(this);
		handlers();		
		
		
		//Creates a pane for the inside window. 2 Rows, 1 Column
		Container pane = getContentPane();
		pane.setLayout(new GridLayout(2,1));
		
		
		//Creates/formats/initializes all of the panels for the gui.
		initializePanels();
		assembleTopLeftPanel(leftPanel);
		assembleTopRightPanel(rightPanel);
		assembleBottomPanel(bottomPanel);
		
		topPanel.add(leftPanel, BorderLayout.WEST);
		topPanel.add(rightPanel, BorderLayout.EAST);
		pane.add(topPanel, BorderLayout.NORTH);
		pane.add(bottomPanel, BorderLayout.CENTER);
		
		centerGUIonScreen(LENGTH, HEIGHT);
	}
	/*****************************************************************************************
	 ****************************************************************************************/		
	
	
	
	
	/*****************************************************************************************
	 * Creates handlers and actionListeners for each button.
	 ****************************************************************************************/
	public void handlers()
	{
		connectDatabaseHandler = new connectButtonHandler();
		connectToDatabaseButton.addActionListener(connectDatabaseHandler);
		
		disconnectDatabaseHandler = new disconnectButtonHandler();
		disconnectFromDatabaseButton.addActionListener(disconnectDatabaseHandler);
		
		clearSQLCommandHandler = new clearCommandButtonHandler();
		clearSQLCommandButton.addActionListener(clearSQLCommandHandler);
		
		executeCommandHandler = new executeCommandButtonHandler();
		executeSQLCommandButton.addActionListener(executeCommandHandler);
		
		clearResultHander = new clearResultButtonHandler();
		clearResultWindowButton.addActionListener(clearResultHander);
		
		closeApplicationHandler = new closeButtonHandler();
		closeApplicationButton.addActionListener(closeApplicationHandler);
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Connect" Button implementation
	 ****************************************************************************************/
	private class connectButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event) 
		{
			FileInputStream fileData;

			properties = new Properties();

			try
			{
				//Checks is there is a connection. Closes the connection if there is.
				if(connection != null)
				{
					connection.close();
				}
				connectionStatusHeader.setBackground(Color.red);
				connectionStatusHeader.setText("NO CONNECTION ESTABLISHED");
				
				
				try
				{
					String userInputUsername = "";
					String selectedUserProperties = "";
					String selectedDatabaseProperties = "";
					char[] passwordCharArray;
					String passwordDecoded = "";
					String propertiesUsername = "";
					String propertiesPassword = "";
					String propertiesURL = "";
					
					
					//Gets user input username and password from GUI.
					userInputUsername = usernameTextfield.getText();
					passwordCharArray = passwordField.getPassword();
					passwordDecoded = String.valueOf(passwordCharArray);
					
					
					selectedUserProperties = userPropertiesDropdown.getSelectedItem().toString();
					try 
					{
						//Gets the username and properties from the selected dropdown in the GUI.
						fileData = new FileInputStream(selectedUserProperties);
						properties.load(fileData);
						propertiesUsername = properties.getProperty("MYSQL_DB_USERNAME");
						propertiesPassword = properties.getProperty("MYSQL_DB_PASSWORD");						
						
						//Checks if the user input is the same as the actual username and password. If it is, it will create a connection with the server the user selected from the dropdown.
						if((userInputUsername.equals(propertiesUsername)) && passwordDecoded.equals(propertiesPassword))
						{							
							selectedDatabaseProperties = databaseURLPropertiesDropdown.getSelectedItem().toString();
							fileData = new FileInputStream(selectedDatabaseProperties);
							properties.load(fileData);
							propertiesURL = properties.getProperty("MYSQL_DB_URL");
							
							
							dataSource = new MysqlDataSource();
							
							dataSource.setURL(propertiesURL);
							dataSource.setUser(propertiesUsername);
							dataSource.setPassword(propertiesPassword);							
							
							connection = dataSource.getConnection();
						
							connectionStatusHeader.setBackground(Color.green);
							connectionStatusHeader.setText("* * * CONNECTED TO: " + propertiesURL + " * * *");
						}
						//If it doesn't it will display an error.
						else
						{
							JOptionPane.showMessageDialog(null, "Incorrect credentials. Please try again.", "INCORRECT LOGIN", JOptionPane.ERROR_MESSAGE);
						}
					}
					catch(SQLException e)
					{
						JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
					}
				}
				catch(IOException e)
				{
					JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
			}
			
			

			
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Disconnect" Button implementation
	 ****************************************************************************************/
	private class disconnectButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event) 
		{
			try 
			{
				//Checks is there is a connection. Closes the connection if there is.
				if(connection != null)
				{
					connection.close();
				}
				connectionStatusHeader.setBackground(Color.red);
				connectionStatusHeader.setText("NO CONNECTION ESTABLISHED");
			} 
			catch (SQLException e) 
			{
				JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Clear Command" Button implementation
	 ****************************************************************************************/
	private class clearCommandButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event) 
		{
			sqlCommandTextArea.setText("");
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Execute Command" Button implementation
	 ****************************************************************************************/
	private class executeCommandButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event) 
		{
			try
			{
				//Creates a new table model and enables it.
				sqlResultTable.setEnabled(true);		
				
				tableModel = new ResultSetTableModel(connection, sqlCommandTextArea.getText());
				
				
				//If the command is a query (it detects SELECT) it will call the query function in the ResultSetTableModel.
				if (sqlCommandTextArea.getText().toUpperCase().contains("SELECT"))
				{
					//Calls query
					tableModel.setQuery(sqlCommandTextArea.getText());
					sqlResultTable.setModel(tableModel);
				}
				//If it is not a query, it will call update.
				else
				{
					//Calls update
					
					//Clears the JTable.
					sqlResultTable.setModel(new DefaultTableModel());
					sqlResultTable.setEnabled(false);
					
					//Checks how many rows are updated.
					int result = tableModel.setUpdate(sqlCommandTextArea.getText());
					
					//If the return (rows updated as an int) is above 0, it must have been successful.
					if (result > 0)
					{
						JOptionPane.showMessageDialog(null, "Successful Update... " + result + " rows updated.", "Successful Update", JOptionPane.INFORMATION_MESSAGE);
					}
					else
					{
						throw new SQLException("Update unsuccessful.");
					}
				}
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
			}
			catch(ClassNotFoundException NotFound)
			{
				JOptionPane.showMessageDialog(null, NotFound.getMessage(), "CLASS NOT FOUND ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Clear Result" Button implementation
	 ****************************************************************************************/
	private class clearResultButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			sqlResultTable.setModel(new DefaultTableModel());
			sqlResultTable.setEnabled(false);
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
	
	/*****************************************************************************************
	 * "Close" Button implementation
	 ****************************************************************************************/
	private class closeButtonHandler implements ActionListener
	{
		public void actionPerformed(ActionEvent event) 
		{
			try 
			{
				//Checks is there is a connection. Closes the connection if there is.
				if(connection != null)
				{
					connection.close();
				}
			} 
			catch (SQLException e) 
			{
				JOptionPane.showMessageDialog(null, e.getMessage(), "DATABASE ERROR", JOptionPane.ERROR_MESSAGE);
			}
			//Closes the gui.
			System.exit(0);
		}
	}
	/*****************************************************************************************
	 ****************************************************************************************/		
	
	
	
	
	
	/*****************************************************************************************
	 * This chunk of methods create and format panels for the GUI
	 ****************************************************************************************/
	//This is the panel for the SQL Execution Result 
	public void assembleBottomPanel(JPanel bottomPanel)
	{
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
		
		JPanel bottomPanelHeader = new JPanel();
		bottomPanelHeader.add(connectionStatusHeader);
		bottomPanelHeader.setMaximumSize(bottomPanelHeader.getPreferredSize());
		
		JPanel bottomPanelLabel = new JPanel();
		//bottomPanelContent.setLayout(new GridLayout(0, 1));
		bottomPanelLabel.add(sqlExecutionWindowLabel);
		bottomPanelLabel.setMaximumSize(bottomPanelLabel.getPreferredSize());
		
		JScrollPane bottomPanelTable = new JScrollPane(sqlResultTable);
		bottomPanelTable.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		bottomPanelTable.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		bottomPanelTable.setMaximumSize(new Dimension(1200, 400));
		//bottomPanelTable.setMaximumSize(bottomPanelTable.getPreferredSize());
		
		JPanel bottomPanelButtons = new JPanel();
		bottomPanelButtons.setLayout(new FlowLayout(FlowLayout.CENTER));
		bottomPanelButtons.add(clearResultWindowButton);
		bottomPanelButtons.add(Box.createHorizontalStrut(10));
		bottomPanelButtons.add(closeApplicationButton);
		
		
		bottomPanel.add(bottomPanelHeader);
		bottomPanel.add(bottomPanelLabel);
		bottomPanel.add(bottomPanelTable);
		bottomPanel.add(bottomPanelButtons);
	}
	
	//This is the panel for the SQL Command section
	public void assembleTopRightPanel(JPanel rightPanel)
	{
		rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
		
		JPanel rightPanelLabel = new JPanel();
		rightPanelLabel.add(sqlCommandLabel);
		rightPanelLabel.setMaximumSize(rightPanelLabel.getPreferredSize());
		
		JScrollPane rightPanelTextArea = new JScrollPane(sqlCommandTextArea);
		rightPanelTextArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		rightPanelTextArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		rightPanelTextArea.setMaximumSize(rightPanelTextArea.getPreferredSize());
		
		JPanel rightPanelButtons = new JPanel();
		rightPanelButtons.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		rightPanelButtons.add(Box.createVerticalStrut(75));
		rightPanelButtons.add(clearSQLCommandButton);
		rightPanelButtons.add(Box.createHorizontalStrut(10));
		rightPanelButtons.add(executeSQLCommandButton);
	
		
		rightPanel.add(rightPanelLabel);
		rightPanel.add(rightPanelTextArea);
		rightPanel.add(rightPanelButtons);
	}
	
	//This is the panel for Connection Details for the SQL Database
	public void assembleTopLeftPanel(JPanel leftPanel)
	{
		leftPanel.setLayout(new BorderLayout());
		
		
		//This creates grid bag constraints that allow for the formatting I did.
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		gridBagConstraints.insets = new Insets(5, 5, 19, 5); gridBagConstraints.anchor = GridBagConstraints.CENTER;
		
		JPanel leftPanelContent = new JPanel();
		leftPanelContent.setLayout(new GridBagLayout());
		
	
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 0;
		leftPanelContent.add(connectionDetailsLabel, gridBagConstraints);
		
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 1;
		leftPanelContent.add(databaseURLPropertiesLabel, gridBagConstraints);
		gridBagConstraints.gridx = 1;
		leftPanelContent.add(databaseURLPropertiesDropdown, gridBagConstraints);
		
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 2;
		leftPanelContent.add(userPropertiesLabel, gridBagConstraints);
		gridBagConstraints.gridx = 1;
		leftPanelContent.add(userPropertiesDropdown, gridBagConstraints);
		
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 3;
		leftPanelContent.add(usernameLabel, gridBagConstraints);
		gridBagConstraints.gridx = 1;
		leftPanelContent.add(usernameTextfield, gridBagConstraints);
		
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 4;
		leftPanelContent.add(passwordLabel, gridBagConstraints);
		gridBagConstraints.gridx = 1;
		leftPanelContent.add(passwordField, gridBagConstraints);
		
		gridBagConstraints.gridx = 0; gridBagConstraints.gridy = 5;
		leftPanelContent.add(connectToDatabaseButton, gridBagConstraints);
		gridBagConstraints.gridx = 1;
		leftPanelContent.add(disconnectFromDatabaseButton, gridBagConstraints);
		
		leftPanel.add(leftPanelContent, BorderLayout.NORTH);
	}
	
	//This sets up the foundation of the formatting for the panels on the GUI
	public void initializePanels()
	{
		topPanel = new JPanel(new GridLayout(1,2));
		bottomPanel = new JPanel(new FlowLayout());
		
		leftPanel = new JPanel(new FlowLayout());
		rightPanel = new JPanel(new FlowLayout());
		
		topPanel.add(leftPanel);
		topPanel.add(rightPanel);
	}
	
	//Function from PROF to center gui on screen
	public void centerGUIonScreen(int frameLength, int frameHeight)
	{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		Dimension screenSize = toolkit.getScreenSize();
		
		int GUIxPosition = (screenSize.width - frameLength) / 2;
		int GUIyPosition = (screenSize.height - frameHeight) / 2;
		
		setBounds(GUIxPosition, GUIyPosition, frameLength, frameHeight);
	}
	/*****************************************************************************************
	 ****************************************************************************************/	
	
	
	
	
		
	public static void main(String[] args) 
	{
		JFrame mainGUI = new Project_3_Final();
		mainGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainGUI.setVisible(true);
	}
}

