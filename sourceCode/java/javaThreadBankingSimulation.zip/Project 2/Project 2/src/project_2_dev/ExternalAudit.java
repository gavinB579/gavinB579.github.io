/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.util.Random;

public class ExternalAudit implements Runnable
{
	private static final int MAX_SLEEP_TIME = 5500;
	
	private static Random sleepTime = new Random();
	
	private BankAccount externalAccount1;
	private BankAccount externalAccount2;
	
	private String externalAuditName;

	
	
	//Gets sent two instances of BankAccount and a thread name
	public ExternalAudit (BankAccount bankAccount1, BankAccount bankAccount2, String requestID)
	{
		externalAccount1 = bankAccount1;
		externalAccount2 = bankAccount2;
		externalAuditName = requestID;
	}
	
	
	
	public void run() 
	{
		//infinite uncounted loop
		while (true)
		{
			//Tries to obtain locks on both instances of BankAccount. If it cannot, it will NOT block and will release whatever locks it had, and try again later.
			if (externalAccount1.threadLock.tryLock())
			{
				try
				{
					if (externalAccount2.threadLock.tryLock())
					{
						try
						{			
							//print headings, # of transactions since last external audit, run audit numbers and print results, reset # of transaction counters
							System.out.println("\n\n\n*********************************************************************************************************************************\n\n");
							System.out.println("UNITED STATES DEPARTMENT OF TREASURY - Bank Audit Beginning...\n");
							System.out.println("Total number of transactions since the last TREASURY DEPARTMENT AUDIT is: " + (BankAccount.transactionNumber - BankAccount.externalAuditCounter) + "\n");
							System.out.println(externalAuditName + " finds current account balance for BA-1 to be: $" + externalAccount1.getAccountBalance());
							System.out.println(externalAuditName + " finds current account balance for BA-2 to be: $" + externalAccount2.getAccountBalance());
							System.out.println("\nUNITED STATES DEPARTMENT OF TREASURY - Bank Audit Terminated...\n\n");
							System.out.println("*********************************************************************************************************************************\n\n\n");
							BankAccount.externalAuditCounter = BankAccount.transactionNumber;
						}
						catch (Exception e)
						{
							System.out.println("Exception thrown trying to lock externalAccount2 on External Audit.");
						}
						finally
						{
							externalAccount2.threadLock.unlock();
						}
					}
				}
				catch (Exception e)
				{
					System.out.println("Exception thrown trying lock externalAccount1 on External Audit.");
				}
				finally
				{
					externalAccount1.threadLock.unlock();
				}
			}
			try
			{
				//Random thread sleep timer
				Thread.sleep(sleepTime.nextInt(MAX_SLEEP_TIME) + 1);
			}
			catch (Exception e)
			{
				System.out.println("Exception thrown at the end of the External class.");
			}
			
		}	
	}

}