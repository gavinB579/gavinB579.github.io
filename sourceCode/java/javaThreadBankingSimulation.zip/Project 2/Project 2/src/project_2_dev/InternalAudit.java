/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.util.Random;

public class InternalAudit implements Runnable
{
	private static final int MAX_SLEEP_TIME = 4500;
	
	private static Random sleepTime = new Random();
	
	private BankAccount externalAccount1;
	private BankAccount externalAccount2;
	
	private String internalAuditName;

	
	//Gets sent two instances of BankAccount and a thread name
	public InternalAudit (BankAccount bankAccount1, BankAccount bankAccount2, String requestID)
	{
		externalAccount1 = bankAccount1;
		externalAccount2 = bankAccount2;
		internalAuditName = requestID;
	}
	
	
	
	public void run() 
	{

		//infinite uncounted loop
		while (true)
		{
			//Tries to obtain locks on both instances of BankAccount. If it cannot, it will NOT block and will release whatever locks it had, and try again later.
			if (externalAccount1.threadLock.tryLock())
			{
				try
				{
					if (externalAccount2.threadLock.tryLock())
					{
						try
						{
							//print headings, # of transactions since last internal audit, run audit numbers and print results, reset # of transaction counters
							System.out.println("\n\n\n*********************************************************************************************************************************\n\n");
							System.out.println("INTERNAL BANK AUDIT Beginning...\n");
							System.out.println("Total number of transactions since the last INTERNAL AUDIT is: " + (BankAccount.transactionNumber - BankAccount.internalAuditCounter) + "\n");
							System.out.println(internalAuditName + " finds current account balance for BA-1 to be: $" + externalAccount1.getAccountBalance());
							System.out.println(internalAuditName + " finds current account balance for BA-2 to be: $" +externalAccount2.getAccountBalance());
							System.out.println("\nINTERNAL BANK AUDIT Complete\n\n");
							System.out.println("*********************************************************************************************************************************\n\n\n");
							BankAccount.internalAuditCounter = BankAccount.transactionNumber;
						}
						catch (Exception e)
						{
							System.out.println("Exception thrown trying to lock externalAccount2 on Internal Audit.");
						}
						finally
						{
							externalAccount2.threadLock.unlock();
						}
					}
				}
				catch (Exception e)
				{
					System.out.println("Exception thrown trying lock InternalAccount1 on External Audit.");
				}
				finally
				{
					externalAccount1.threadLock.unlock();
				}
			}
			try
			{
				//Random thread sleep timer
				Thread.sleep(sleepTime.nextInt(MAX_SLEEP_TIME) + 1);
			}
			catch (Exception e)
			{
				System.out.println("Exception thrown at the end of the Internal Audit class.");
			}
		}

	}
}


