/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.*;


public class BankAccount implements Bank
{
	//Per instance account balance.
	private int accountBalance = 0;
	
	private static final int DEPOSIT_FLAG_AMOUNT = 450;
	private static final int WITHDRAWAL_FLAG_AMOUNT = 90;
	
	
	
	//Where locks are made as reentrant locks. Also creates a condition for deposit completed.
	public Lock threadLock = new ReentrantLock();
	private Condition depositCompleted = threadLock.newCondition();
	
	
	
	//Shared across instances counters for transactions and audits.
	public static int transactionNumber = 1;
	public static int internalAuditCounter = 1;
	public static int externalAuditCounter = 1;
	
	
	
	//Gets sent data from the Depositor class.
	public void deposit(int depositAmount, String accountNumber, String requestID) 
	{
		//Locks the class.
		threadLock.lock();
		try
		{
			//Adjusts account balance and puts a print statement. Also checks to see if the amount deposited is above the flagged limit, which would then send information to the flagged_transaction method if it was.
			accountBalance += depositAmount;
			System.out.println("Deposit Agent " + requestID + " deposits $" + depositAmount + " into account " + accountNumber + "\t\t\t\t\t\t\t (+) Balance is: $" + accountBalance + "\t\t\t\t\t\t" + transactionNumber + "\n");
			if (depositAmount >= DEPOSIT_FLAG_AMOUNT)
			{
				flagged_transaction(DEPOSIT_FLAG_AMOUNT, requestID, "deposit", depositAmount);
			}
			//Increases the transaction counter.
			transactionNumber++;
			
			//Signals all threads that a deposit has been completed.
			depositCompleted.signalAll();
		}
		catch (Exception e)
		{
			System.out.println("Exception thrown while making a deposit.");
		}
		finally
		{
			//Unlocks the thread
			threadLock.unlock();
		}
	}

	
	
	//Simply returns the account balance per instance whenever called outside of the class.
	public int getAccountBalance()
	{
		return accountBalance;
	}
	
	
	
	//Sets the account balance per instance based on whatever it is sent. 
	public void setAccountBalance(int newBalance)
	{
		accountBalance = newBalance;
	}
	
	
	
	//Gets sent data from the Withdrawer class.
	public void withdraw(int withdrawalAmount, String accountNumber, String requestID) 
	{
		//Locks the class
		threadLock.lock();
		try
		{
			//If the amount being withdrawn is more than what is in the account, it obviously cannot be withdrawn without overdrafting, which is not implemented in this program.
			//If it cannot be done, it will print a statement about the failed attempt and wait on a signal from deposit.
			if(withdrawalAmount > accountBalance)
			{
				System.out.println("\t\t\t\t\t\tAgent " + requestID + " attempts to withdraw $" + withdrawalAmount + " from " + accountNumber + "\t\t WITHDRAWAL BLOCKED - INSUFFICIENT FUNDS!!! Balance is only $" + accountBalance + "\n");
				depositCompleted.await();
			}
			//Otherwise, it will continue with the transaction, incrementing the transaction number, printing completed transaction statements, and checking for flagged transactions.
			else
			{
				accountBalance -= withdrawalAmount;
				System.out.println("\t\t\t\t\t\tAgent " + requestID + " withdraws $" + withdrawalAmount + " from " + accountNumber + "\t\t\t (-) Balance is: $" + accountBalance + "\t\t\t\t\t\t" + transactionNumber + "\n");
				
				if (withdrawalAmount >= WITHDRAWAL_FLAG_AMOUNT)
				{
					flagged_transaction(WITHDRAWAL_FLAG_AMOUNT, requestID, "withdrawal", withdrawalAmount);
				}
				transactionNumber++;
			}
		}
		catch (Exception e)
		{
			System.out.println("Exception thrown while making a withdrawal");
		}
		finally
		{
			//Unlocks the thread
			threadLock.unlock();
		}
	}

	
	
	//This is the flagged transaction method, it gets sent data from other classes and methods. 
	public void flagged_transaction(int flaggedTransactionAmount, String requestID, String transactionType, int transactionValue) 
	{
		//File writer to write flagged transactions to a transaction log.
		FileWriter appendFile = null;
		BufferedWriter appendFileBuf = null;
		
		//Date and time formatting for logging purposes.
		LocalDateTime currentTime = LocalDateTime.now();
		DateTimeFormatter timeFormatNum = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
		String currentTimeStrNum = currentTime.format(timeFormatNum);
		
		//Prints out a statement for the console/output text file.
		System.out.println("* * * FLAGGED TRANSACTION * * * AGENT " + requestID + " MADE A " + transactionType + " IN EXCESS OF $" + flaggedTransactionAmount + ".00 USD - SEE FLAGGED TRANSACTION LOG. * * * FLAGGED TRANSACTION * * *\n");
		
		//This block just writes the flagged data to the transaction log.
		try
		{
			appendFile = new FileWriter("transactions.csv", true);
			appendFileBuf = new BufferedWriter(appendFile);
			
			appendFileBuf.write("Agent " + requestID + " issued a " + transactionType + " of $" + transactionValue + " at: " + currentTimeStrNum + "\t Transaction Number: " + transactionNumber + "\n");
			
			appendFileBuf.newLine();
			appendFileBuf.close();
		}
		catch (FileNotFoundException fileNotFoundException)
		{
			System.out.println("Error: File not found.");
		}
		catch (IOException ioException)
		{
			System.out.println("Error: Problem writing to file.");
		}
	} 
}
