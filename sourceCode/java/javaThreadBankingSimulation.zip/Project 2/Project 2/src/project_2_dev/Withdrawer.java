/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.util.Random;

public class Withdrawer implements Runnable
{
	//Variables used
	private static final int MAX_WITHDRAW = 99;
	private static final int MAX_SLEEP_TIME = 200;
	
	private static Random withdrawAmount = new Random();
	private static Random sleepTime = new Random();
	
	private BankAccount externalAccount1;
	private BankAccount externalAccount2;
	
	private int accountNumber;
	private String withdrawerName;
	
	
	
	//Gets sent two instances of BankAccount and a thread name
	public Withdrawer (BankAccount bankAccount1, BankAccount bankAccount2, String requestID)
	{
		externalAccount1 = bankAccount1;
		externalAccount2 = bankAccount2;
		withdrawerName = requestID;		
	}

	
	
	public void run() 
	{
		//infinite uncounted loop
		while(true)
		{
			//Will sleep first to offset the start of the program being dominated by totally withdrawals/deposits. 
			try
			{
				Thread.sleep(sleepTime.nextInt(MAX_SLEEP_TIME) + 1);
				//This will be random num gen to make a withdraw
				accountNumber = (int)(Math.random() * 2);
				
				//Switch case to determine where it makes the withdrawal based on random number gen. 
				switch (accountNumber)
				{
				case 0:
					externalAccount1.withdraw(withdrawAmount.nextInt(MAX_WITHDRAW) + 1, "BA-1", withdrawerName);
				case 1:
					externalAccount2.withdraw(withdrawAmount.nextInt(MAX_WITHDRAW) + 1, "BA-2", withdrawerName);
				}							
			}
			catch (Exception e)
			{
				System.out.println("Exception thrown when trying to deposit from depositor.");
			}
		}
	}

}
