/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

//Allowed behaviors for the bank account
public interface Bank 
{
	//Deposit amount, the account number, and the name of the person doing it
	public abstract void deposit (int depositAmount, String accountNumber, String requestID);
	
	//Withdrawal amount, name of the person doing it
	public abstract void withdraw (int withdrawalAmount, String accountNumber, String requestID);
	
	//Use D for depositor threat type and W for withdrawal
	public abstract void flagged_transaction (int flaggedTransactionAmount, String requestID, String transactionType, int transactionValue);
}
