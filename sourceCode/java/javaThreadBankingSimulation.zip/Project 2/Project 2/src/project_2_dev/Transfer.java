/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.util.Random;

public class Transfer implements Runnable
{
	private static final int MAX_SLEEP_TIME = 2500;
	private static final int MAX_TRANSFER_VALUE = 750;
	private static final int TRANSFER_FLAG_AMOUNT = 500;
	
	private static Random transferAmount = new Random();
	private static Random sleepTime = new Random();
	
	private BankAccount externalAccount1;
	private BankAccount externalAccount2;
	
	private int accountNumber;
	private String transferAgentName;

	//Gets sent two instances of BankAccount and a thread name
	public Transfer (BankAccount bankAccount1, BankAccount bankAccount2, String requestID)
	{
		externalAccount1 = bankAccount1;
		externalAccount2 = bankAccount2;
		transferAgentName = requestID;
	}
	
	public void run() 
	{
		//infinite uncounted loop
			while (true)
			{
				//Creates a variable with a random number gen saved to it until the next loop. Keeps everything consistent when it needs to be.
				int amountToTransfer = (transferAmount.nextInt(MAX_TRANSFER_VALUE) + 1);
				
				//This series of locks is important. Both accounts have to be locked according to the instructions. They also must not block, and must only acquire lock if it is available, otherwise they must try again later.
				//These are try locks, so they will try to lock and if they aren't available, they will stop.
				if (externalAccount1.threadLock.tryLock())
				{		
					try
					{						
						if(externalAccount2.threadLock.tryLock())
						{
							try
							{
								//Random num gen to determine which bank account to transfer from/to.
								accountNumber = (int)(Math.random() * 2);

								//Switch case that selects a case depending on the random num gen above.
								//Each case does functionally the same thing, just for different accounts. They both adjust the account balances if a transfer is possible (i.e. enough account balance)
								//They also both print either success statements or failed statements, as well as flags. They also increment the transaction counter.
								switch (accountNumber)
								{
								case 0:
									if (externalAccount1.getAccountBalance() >= amountToTransfer)
									{
										externalAccount1.setAccountBalance(externalAccount1.getAccountBalance() - amountToTransfer);
										externalAccount2.setAccountBalance(externalAccount2.getAccountBalance() + amountToTransfer);
										System.out.println("\t\tTRANSFER --> Agent " + transferAgentName + " transferred $" + amountToTransfer + " from BA-1 to BA-2 - - BA-2 balance is now $" + externalAccount2.getAccountBalance() + "\t\t\t\t\t\t\t " + BankAccount.transactionNumber);
										System.out.println("\t\tTRANSFER COMPLETE --> Account BA-1 balance is now $" + externalAccount1.getAccountBalance() + "\n");
										if (amountToTransfer > TRANSFER_FLAG_AMOUNT)
										{
											externalAccount1.flagged_transaction(TRANSFER_FLAG_AMOUNT, transferAgentName, "TRANSFER", amountToTransfer);
										}
										BankAccount.transactionNumber++;
									}
									else
									{
										System.out.println("\t\tTRANSFER --> Agent " + transferAgentName + " attempts to transfer $" + amountToTransfer + " from BA-1 to BA-2. Balance only $" + externalAccount1.getAccountBalance() + "(******) TRANSFER ABORTED - INSUFFICIENT FUNDS!!!\n");
									}

								case 1:
									if (externalAccount2.getAccountBalance() >= amountToTransfer)
									{
										externalAccount2.setAccountBalance(externalAccount2.getAccountBalance() - amountToTransfer);
										externalAccount1.setAccountBalance(externalAccount1.getAccountBalance() + amountToTransfer);
										System.out.println("\t\tTRANSFER --> Agent " + transferAgentName + " transferred $" + amountToTransfer + " from BA-2 to BA-1 - - BA-1 balance is now $" + externalAccount1.getAccountBalance() + "\t\t\t\t\t\t\t " + BankAccount.transactionNumber);
										System.out.println("\t\tTRANSFER COMPLETE --> Account BA-2 balance is now $" + externalAccount2.getAccountBalance() + "\n");
										if (amountToTransfer > TRANSFER_FLAG_AMOUNT)
										{
											externalAccount2.flagged_transaction(TRANSFER_FLAG_AMOUNT , transferAgentName, "TRANSFER", amountToTransfer);
										}
										BankAccount.transactionNumber++;
									}
									else
									{
										System.out.println("\t\tTRANSFER --> Agent " + transferAgentName + " attempts to transfer $" + amountToTransfer + " from BA-2 to BA-1. Balance only $" + externalAccount2.getAccountBalance() + "(******) TRANSFER ABORTED - INSUFFICIENT FUNDS!!!\n");
									}
								}
							}
							catch (Exception e)
							{
								System.out.println("Exception thrown trying to lock externalAccount2 on transfer.");
							}
							finally
							{
								//Unlocks account2 lock.
								externalAccount2.threadLock.unlock();
							}
						}
					}
					catch (Exception e)
					{
						System.out.println("Exception thrown trying to lock externalAccount1 on transfer.");
					}
					finally
					{
						//Unlocks account1 lock.
						externalAccount1.threadLock.unlock();
					}
			}
			try
			{
				//Random thread sleep timer.
				Thread.sleep(sleepTime.nextInt(MAX_SLEEP_TIME) + 1);
			}
			catch (Exception e)
			{
				System.out.println("Exception thrown at the end of the transaction class.");
			}
		}
		
	}

}
