/* Name: Gavin Bates
Course: CNT 4714 Fall 2025
Assignment title:
Project 2 – Synchronized/Cooperating Threads – A Banking Simulation
Due Date: September 28, 2025
*/
package project_2_dev;

import java.util.concurrent.*;

public class BankingSim 
{
	private static final int MAX_THREADS = 20;
	
	private static final int MAX_DEPOSIT_AGENTS = 5;
	private static final int MAX_WITHDRAW_AGENTS = 10;
	private static final int MAX_TRANSFER_AGENTS = 2;

	
	
	//Names for some of the threads. Used in initializing when there is more than one thread to initialize.
	//My naming convention uses the first letter of each word to where it goes --> Deposit Agent # = DA-# or DA-1, DA-2, DA-3...
	static String[] depositAgents = new String[] {"DA-1", "DA-2", "DA-3", "DA-4", "DA-5"};
	static String[] withdrawAgents = new String[] {"WA-1", "WA-2", "WA-3", "WA-4", "WA-5", "WA-6", "WA-7", "WA-8", "WA-9", "WA-10"};
	static String[] transferAgents = new String[] {"TA-1", "TA-2"};
	
	
	
	public static void main(String[] args) 
	{
		//Creates a thread executor.
		ExecutorService simulator = Executors.newFixedThreadPool(MAX_THREADS);
		
		//Creates 2 instances of BankAccount to be sent to the other classes.
		BankAccount bankAccount1 = new BankAccount();
		BankAccount bankAccount2 = new BankAccount();
		
		try
		{
			//Formatting
			System.out.println("--**--SIMULATOR BEGINS--**--\n");
			System.out.println("DEPOSIT AGENTS\t\t\t\t\t   WITHDRAWAL AGENTS\t\t\t\t\t   BALANCES\t\t\t\t\t   TRANSACTION NUMBER");
			System.out.println("--------------\t\t\t\t\t   -----------------\t\t\t\t\t   --------\t\t\t\t\t   ------------------");
			//MAX_SLEEP_TIME for Withdrawals = 200 || MAX_SLEEP_TIME for Deposits = 1700 || MAX_SLEEP_TIME for transfers = 2500 || MAX_SLEEP_TIME for internal audit = 400 || MAX_SLEEP_TIME for external audit = 5500
		}
		catch (Exception e)
		{
			System.out.println("Exception thrown. Something went wrong.");
		}
		
		//This block initializes and executes my threads. For classes that have more than one thread to initialize, I use a for Loop that counts to the max allowed threads of their kinds (i.e. max withdrawal threads, or max deposit threads.)
		//This is where I use the string arrays, and it iterates through the names as it iterates through the loops.
		for(int i = 0; i < MAX_DEPOSIT_AGENTS; i++)
		{
			simulator.execute(new Depositor (bankAccount1, bankAccount2, depositAgents[i]));
		}
		for (int i = 0; i < MAX_WITHDRAW_AGENTS; i++)
		{
			simulator.execute(new Withdrawer(bankAccount1, bankAccount2, withdrawAgents[i]));
		}
		for (int i = 0; i < MAX_TRANSFER_AGENTS; i++)
		{
			simulator.execute(new Transfer(bankAccount1, bankAccount2, transferAgents[i]));
		}
		simulator.execute(new InternalAudit(bankAccount1, bankAccount2, "IAA-1"));
		simulator.execute(new ExternalAudit(bankAccount1, bankAccount2, "TAA-1"));
		
		
		
		simulator.shutdown();
	}

}
