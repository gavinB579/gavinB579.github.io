package project1;


/* Name: Gavin Bates
 * Course: CNT 4714 - Fall 2025
 * Assignment Title: Project 1 - An Event-Driven Enterprise Simulation
 * Date: Sunday September 7, 2025 
 */

public class EventDrivenProgramming {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
