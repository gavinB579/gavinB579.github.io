package project1;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Scanner;

//split command

public class ItemNumberSearch 
{

	private static void targetFileReader() 
	{
		File targetFile = new File("inventory.csv");
		FileReader targetFileReader = null;
		BufferedReader targetFileBufReader = null;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter ID: ");
		String userInput = scanner.next();
		try
		{
			targetFileReader = new FileReader(targetFile);
			targetFileBufReader = new BufferedReader(targetFileReader);
			String lineFromFile = targetFileBufReader.readLine();
			
			
			while(lineFromFile != null)
			{
				System.out.println(lineFromFile);
				lineFromFile = targetFileBufReader.readLine();
			}
			
			
		} 
		catch (FileNotFoundException fileNotFoundException)
		{
			System.out.println("Error 1");
		}
		catch (IOException ioException)
		{
			System.out.println("Error 2");
		}
	}
	
	public static void main(String [] args)
	{
		targetFileReader();
	}

}
