/*
COP 3502C Assignment 4
This program is written by: Gavin Bates
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define _USE_MATH_DEFINES
#include <math.h>

//These are my structs. They hold the required variables.
typedef struct Group
{
    int groupSize, groupNum;
    double radAngle;
}Group;
typedef struct Result
{
    int firstGroup, secondGroup;
    double degAngle;
}Result;


//This is the doubleCompare function. It is used to compare doubles. If d1-d2 has a result that is less than 0.0001 it returns 1. Otherwise, it returns 0.
int doubleCompare(double d1, double d2, double eps)
{
    if (fabs(d1 - d2) < eps)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//This is the compareTo function. It takes in 2 pointers, both of type result and either returns a -1, 0, or 1.
int compareTo(Result *ptrPt1, Result *ptrPt2)
{

    //It returns a negative 1 if the left first group is less than the right first group.
    if (ptrPt1->firstGroup < ptrPt2->firstGroup)
    {
        return -1;
    }
    //If both first groups are equal, it needs to do deeper sorting.
    else if (ptrPt1->firstGroup == ptrPt2->firstGroup)
    {
        //If the left second group is smaller than the right second group, it returns 1.
        if (ptrPt1->secondGroup < ptrPt2->secondGroup)
        {
            return -1;
        }

        //If both groups are exactly the same (both first and second groups are equal) it returns 0.
        else if (ptrPt1->secondGroup == ptrPt2->secondGroup)
        {
            return 0;
        }

        //It returns a 1 in any the case that right second group is smaller than the left second group.
        else
        {
            return 1;
        }
    }

    //If returns a 1 in any other case.
    else
    {
        return 1;
    }
}

//This is the merge2 function. It works very similarly to the merge/mergeSort functions. The only main difference is that it calls compareTo to do deeper sorting when necessary.
void merge2 (Result *arr, int l, int m, int r)
{

    //Declaring variables needed.
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    //Declaring malloced memory for left and right arrays.
    Result* L = (Result*)malloc(sizeof(Result) * n1 + 1000000);
    Result* R = (Result*)malloc(sizeof(Result) * n2 + 1000000);

    //This for loop fills both arrays. Left side is filled with the mergeSort2 left to mid. Right side is filled with mergeSort2 mid to right.
    for (i = 0; i < n1; i++)
    {
        L[i] = arr[l + i];
    }
    for (j = 0; j < n2; j++)
    {
        R[j] = arr[m + 1 + j];
    }

    //Reset variables.
    i = 0;
    j = 0;
    k = l;

    //This loop merges the main portion of the sorted list. Depending on the returns values from compareTo, it will merge the two sorted lists back together.
    while (i < n1 && j < n2)
    {
        int res = compareTo(&L[i], &R[j]);

        if (res == -1)
        {
            arr[k] = L[i];
            i++;
        }
        else if (res == 0)
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;

    }

    //These two loops just fill in whatever leftover numbers couldn't be compared. Automatically, since the 2 sorted lists have been mostly merged, these should only hold 1 or 2 loose numbers 
    //and they should be bigger than anything already merged.
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }


    //This frees L and R which I malloced earlier.
    free(L);
    free(R);
}

void mergeSort2(Result* arr, int l, int r)
{

    //Base case
    if (l < r)
    {
        //Establish mid point.
        int m = l + (r-l)/2;

        //Recursively call to get both left and right side to use in the merge2 function.
        mergeSort2(arr, l, m);
        mergeSort2(arr, m+1, r);
        
        //Calls merge2 sort merge sorted lists.
        merge2(arr, l, m, r);
    }
}

//This is the merge function.
void merge(Group *arr, int l, int m, int r)
{
    //Declaring variables.
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    //Declaring malloced memory for left and right arrays
    Group* L = (Group*)malloc(sizeof(Group) * n1 + 1000000);
    Group* R = (Group*)malloc(sizeof(Group) * n2 + 1000000);

    //This for loop fills both arrays. Left side is filled with the mergeSort left to mid. Right side is filled with mergeSort mid to right.
    for (i = 0; i < n1; i++)
    {
        L[i] = arr[l + i];
    }
    for (j = 0; j < n2; j++)
    {
        R[j] = arr[m + 1 + j];
    }

    //Reset variables
    i = 0;
    j = 0;
    k = l;

    //This while loop merges the main portion the 2 sorted lists.
    while (i < n1 && j < n2)
    {
        //If the left radian angle is less than or equal to the right radian angle, the left angle will be stored in the array.
        if(L[i].radAngle <= R[j].radAngle)
        {
            arr[k] = L[i];
            i++;
        }

        //Otherwise, left must be bigger so the right radian angle is stored in the array.
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    //These two loops just fill in whatever leftover numbers couldn't be compared. Automatically, since the 2 sorted lists have been mostly merged, these should only hold 1 or 2 loose numbers 
    //and they should be bigger than anything already merged.
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }

    //This frees L and R which I malloced earlier.
    free(L);
    free(R);
}

//This is the mergeSort function.
void mergeSort(Group* arr, int l, int r)
{
    //Base case
    if (l < r)
    {
        //Esablish midpoint
        int m = l + (r-l)/2;

        //Gets left and right parts recursively
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);

        //Calls merge function.
        merge(arr, l, m, r);
    }
}


//This is the main function.
int main()
{
    //Establish variables
    Group *groupTemp;
    Result *resultTemp;
    int s, groupNumLocal, degNumLocal, x, y;
    s = groupNumLocal = degNumLocal = x = y = 0;

    //Scan user inputs.
    scanf("%d %d", &groupNumLocal, &degNumLocal);

    //If the user inputs are outside the realm of what the professor says is possible, exit program.
    if (groupNumLocal >= 500001 || degNumLocal >= 360)
    {
        exit(0);
    }

    //Mallocs memory for both structs as required.
    groupTemp = (Group*)malloc((groupNumLocal + 1000000) * sizeof(Group*));
    resultTemp = (Result*)malloc((groupNumLocal + 1000000) * sizeof(Result*));
    
    //This for loop scans all remaing user inputs and stores them.
    for (int i = 0; i < groupNumLocal; i++)
    {
        scanf("%d %d %d", &x, &y, &s);
        groupTemp[i].groupSize = s;
        groupTemp[i].radAngle = atan2(y, x);
        groupTemp[i].groupNum = i;
    }

    //This calls the merge sort function to sort the list based on radian angle.
    mergeSort(groupTemp, 0, groupNumLocal - 1);

    //This establishes variables for the second half of the project.
    double tempMax = 0;
    double tempArr[groupNumLocal];
    int *tempGroup1= (int*)malloc(sizeof(int*) * groupNumLocal + 1000000);
    int *tempGroup2 = (int*)malloc(sizeof(int*) * groupNumLocal + 1000000);
    int maxArrElem = groupNumLocal - 1;

    //This loop fills temp arrays with the angle (in degrees) and the two group numbers that subtract to get that. It also gets the maximum angle
    for (int i = 0; i < groupNumLocal - 1; i++)
    {
        tempArr[i] = fabs((groupTemp[i + 1].radAngle * 180/M_PI) - (groupTemp[i].radAngle * 180/M_PI));
        tempGroup1[i] = groupTemp[i + 1].groupNum;
        tempGroup2[i] = groupTemp[i].groupNum;

        if (tempMax < tempArr[i])
        {
            tempMax = tempArr[i];
        }

        //This is a special situation. If i + 1 is equal to the final element in the array this activates. We need this specifically so we can get the comparison between
        //the 0th element and the final element. (i.e. if the array is [0,1,2,3,4,5,6] this compares 0 and 6)
        if (i + 1 == maxArrElem)
        {
            tempGroup1[i + 1] = groupTemp[maxArrElem].groupNum;
            tempGroup2[i + 1] = groupTemp[0].groupNum;
            
            tempArr[i + 1] = (360 - fabs((groupTemp[maxArrElem].radAngle * 180/M_PI) - (groupTemp[0].radAngle * 180/M_PI)));

            if (tempMax < tempArr[i + 1])
            {
                tempMax = tempArr[i + 1];
            }
        }
    }    

    //Print statement
    printf("Max projection degree without harming %.4lf\nClosest possible group pairs in order:\n", tempMax);

    int counter = 0;

    //This loop goes through every stores value and checks if the current double is equal to the tempMax (largest double stored)
    //If they are equal (or close enough because of epsilon), it stores the two groups that give that angle (when substracted)
    //If they are not equal, it continues
    for (int i = 0; i < groupNumLocal; i++)
    {
        int doubleResult = doubleCompare(tempArr[i], tempMax, 0.0001);
        if (doubleResult == 1)
        {
            resultTemp[counter].degAngle = tempArr[i];

            //This if/else automatically puts the smaller number in the firstGroup, and the bigger number in the secondGroup.
            if (tempGroup1[i] > tempGroup2[i])
            {
                resultTemp[counter].firstGroup = tempGroup2[i];
                resultTemp[counter].secondGroup = tempGroup1[i];
                counter++;
            }
            else
            {
                resultTemp[counter].firstGroup = tempGroup1[i];
                resultTemp[counter].secondGroup = tempGroup2[i];
                counter++;
            }
        }    
    }


    //This block gets the final value. It has to be done in a special way because it is the final group numbers' radian and the very first group numbers' radian.
    //It is not a loop, it only needs to get the value for this special case.
    int doubleResult2 = doubleCompare(tempArr[maxArrElem], tempMax, 0.0001);
    if (doubleResult2 == 1)
    {
        //This if/else automatically puts the smaller number in the firstGroup, and the bigger number in the secondGroup.
        if (tempGroup1[maxArrElem] > tempGroup2[maxArrElem])
        {
            resultTemp[counter].firstGroup = tempGroup1[maxArrElem];
            resultTemp[counter].secondGroup = tempGroup2[maxArrElem];
        }
        else
        {
            resultTemp[counter].firstGroup = tempGroup2[maxArrElem];
            resultTemp[counter].secondGroup = tempGroup1[maxArrElem];            
        }
    }

    //This calls the mergeSort2 function to sort the stored groups.
    mergeSort2(resultTemp, 0, counter - 1);

    //This for loop prints all of the groups that are closest to the projection.
    for (int i = 0; i < counter; i++)
    {
            printf("%d %d\n", resultTemp[i].firstGroup, resultTemp[i].secondGroup);
    }

    //This frees the malloced memory for the two structs and the temp arrays
    free(tempGroup1);
    free(tempGroup2);
    free(resultTemp);
    free(groupTemp);

    exit(0);

}