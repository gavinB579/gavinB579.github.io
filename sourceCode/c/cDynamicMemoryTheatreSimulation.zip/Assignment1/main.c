
/* COP 3502C Assignment 1
   This program is written by: Gavin Bates*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _CRT_SECURE_NO_WARNINGS

//initial size of any row
#define INITSIZE 10

//maximum length of a name for an order
#define MAXLEN 50

//maximum number of rows in theater
#define MAXROWS 100000



typedef struct order
{
//start seat
int s_seat;

//end seat
int e_seat;

//name of person ordering
char* name;
} order;



typedef struct theaterrow
{
//list of orders
order** list_orders;

//max size of an empty row. if need to realloc, double max_size
int max_size;

//current size of a row
int cur_size;
} theaterrow;



// Returns a pointer to a dynamically allocated order storing the given
// start seat, end seat, and the name this_name. Note: strcpy should be
// used to copy the contents into the struct after its name field is
// dynamically allocated.

//This entire function is temporary. It holds information to organize it to be used later if the order can actually be made.
order* make_order(int start, int end, char* this_name)
{
    order* tempArr = (order*)malloc(sizeof(order));
    tempArr->s_seat = start;
    tempArr->e_seat = end;

    //Plus 1 for the null
    int len = strlen(this_name) + 1;
    tempArr->name = (char*)malloc(len * sizeof(char));
    strcpy(tempArr->name, this_name);
    return tempArr;
}

// This function will allocate the memory for one theaterrow, including
// allocating its array of orders to a default maximum size of 10, and
// setting its current size to 0.
theaterrow* make_empty_row()
{
    //This first malloc allocates memory to for the entire row. It is mallocing out space for order** list_orders, max_size, cur_size. The list for the 10 seats
    theaterrow* row_arr = (theaterrow*)malloc(sizeof(theaterrow));

    //This mallocs out 10 (INITSIZE) seats to store data
    row_arr->list_orders = (order**)malloc(INITSIZE * sizeof(order*));

    row_arr->max_size = INITSIZE;
    row_arr->cur_size = 0;
    return row_arr;
}


// Assuming that order1 and order2 point to orders on the same row, this
// function returns 1 if the orders conflict, meaning that they share 
// at least 1 seat in common, and returns 0 otherwise.
int conflict(order* order1, order* order2)
{

    //These if statements check to see if the potential order will interfere with an already place order. If they will, it returns 0. If not, it returns 1
    if (order1->s_seat == order2->s_seat || order1->e_seat == order2->e_seat || order1->s_seat == order2->e_seat || order1->e_seat == order2->s_seat)
    {
        return 0;
    }
    else if (order1->s_seat >= order2->s_seat && order1->s_seat <= order2->e_seat)
    {
        return 0;
    }
    else if (order1->e_seat >= order2->s_seat && order1->e_seat <= order2->e_seat)
    {
        return 0;
    }
    else if (order2->s_seat >= order1->s_seat && order2->e_seat <= order1->e_seat )
    {
        return 0;
    }

    return 1;
}

// Returns 1 if the order pointed to by this_order can be added to the
// row pointed to by this_row. Namely, 1 is returned if and only if
// this_order does NOT have any seats in it that are part of any order
// already on this_row.
int can_add_order(theaterrow* this_row, order* this_order)
{
    //This checks to see if the rows' current size is 0. If it is, there is no data inside and there cannot be any conflict because of that.
    if (this_row->cur_size == 0)
    {
        return 1;
    }

    //This for loop loops through the total number of used memory in a dynamic array
    //It will send each and every order in the customers chosen row and check. If even 1 order conflicts, it will stop and return 0
    for (int i = 0; i < this_row->cur_size; i++)
    {

        //This checks to see if there is a conflict
        int conflictCheck = conflict(this_order, this_row->list_orders[i]);
        if (conflictCheck == 0)
        {
            return 0;
        }
    }
    return 1;
}


// This function tries to add this_order to this_row. If successful,
// the order is added and 1 is returned. Otherwise, 0 is returned and
// no change is made to this_row. If the memory for this_row is full,
// this function will double the maximum # of orders allocated for the
// row (via realloc), before adding this_order, and adjust max_size and
// cur_size of this_row.
void add_order(theaterrow* this_row, order* this_order)
{   
    //Each row element can hold name, start seat and end seat. THe seats do not actually exist, they are just integers.
    int check = can_add_order(this_row, this_order);

    //If the order can be added, this if block activates
    if (check == 1)
    {
        //This checks to see if there is enough room to store more data. If there isnt, it reallocs
        if (this_row->cur_size == this_row->max_size)   
        {   
            this_row->max_size = this_row->max_size * 2;
            this_row->list_orders = (order**)realloc(this_row->list_orders, sizeof(order*) * (this_row->max_size));     
        }

        this_row->list_orders[this_row->cur_size] = this_order;
        this_row->cur_size = this_row->cur_size + 1;

        printf("SUCCESS\n");
    }

    //If it cant, prints FAILURE
    else
    {
        printf("FAILURE\n");
    }
}

//USE IN LOOKUP
// This function returns 1 if the seat number seat_no is contained in
// the range of seats pointed to by myorder, and returns 0 otherwise.

//This function gets called by get_row_owner and returns a 1 or a 0 depending on the if statement
int contains(order* myorder, int seat_no)
{
    if (seat_no >= myorder->s_seat && seat_no <= myorder->e_seat)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//USE IN LOOKUP
// If seat_num in the row pointed to by this_row is occupied, return a
// pointer to the string storing the owner’s name. If no one is sitting
// in this seat, return NULL.

//This function gets called by get_owner, calls contains, and returns a name or a null depending on what contains returns
char* get_row_owner(theaterrow* this_row, int seat_num)
{
    for (int i = 0; i < this_row->cur_size; i++)
    {
        int containsFuncResult = contains(this_row->list_orders[i], seat_num);
        if (containsFuncResult == 1)
        {
            return this_row->list_orders[i]->name;
        }
    }
    return NULL;
}

//USE IN LOOKUP
// If seat_num seat number in row number row is occupied, return a
// pointer to the owner’s name. Otherwise, return NULL.

//Calls get_row_owner and returns either a pointer to a name or a null depending on what get_row_owner returns
char* get_owner(theaterrow** theater, int row, int seat_num)
{
    char* get_row_owner_char = get_row_owner(theater[row], seat_num);

    if (get_row_owner_char != NULL)
    {
        return get_row_owner_char;
    }
    else
    {
        return NULL;
    }

}

//USE IN EXIT
// Frees all memory associated with this_order.
void free_order(order* this_order)
{   
    //Frees name, then this_order
    free (this_order->name);
    free(this_order);
}

//USE IN EXIT
// Frees all memory associated with this_row.
void free_row(theaterrow* this_row)
{
    //Frees list_orders, then this_row
    free(this_row->list_orders);
    free(this_row);
}

int main ()
{
    //Initializes a spot for each row. Makes MAXROWS+1 rows that all initialize to NULL
    theaterrow** amc_= calloc(MAXROWS+1, sizeof(theaterrow*));

    //Sets up char variables for comparisons
    char Buy[] = "BUY";
    char Lookup[] = "LOOKUP";
    char Exit[] = "EXIT";

    //Loop that runs infinitely until user types "EXIT"
    while (2 != 3)
    {
        //Sets up variables 
        int start_seat = 0, end_seat = 0, row = 0, seat = 0;
        char cus_name[MAXLEN];
        char BuyOrLookupOrExit[7];

        //Scans for user input
        scanf("%s", BuyOrLookupOrExit);
        //strupr(BuyOrLookupOrExit);

       //If the user types BUY, this first if statement will run
        if (strcmp(BuyOrLookupOrExit, Buy) == 0)
        {   
            scanf("%d %d %d %s", &row, &start_seat, &end_seat, cus_name);

            //These 2 if/else if's check if the row is even a viable option
            if (row > MAXROWS)
            {
                printf("FAILURE\n");
            }
            else if (row < 0)
            {
                printf("FAILURE\n");
            }

            //If the row is a viable option, the program continues to this else block
            else
            {

                //Calls the make_order function
                order* arr = make_order(start_seat, end_seat, cus_name);

                //Only creates a new row if the row does not already exist to avoid overwriting information
                if (amc_[row] == NULL)
                {
                    amc_[row] = make_empty_row();
                }

                //Calls the add_order function
                add_order(amc_[row], arr);                
            }
        }

        //If the user types LOOKUP, this block activates
        else if (strcmp(BuyOrLookupOrExit, Lookup) == 0)
        {

            //Scans rest of user inputs
            scanf("%d %d", &row, &seat);

            //Checks to see if the row selected is a viable option. No negatives or rows over the max size
            if (row > MAXROWS)
            {
                printf("FAILURE\n");
            }
            else if (row < 0)
            {
                printf("FAILURE\n");
            }

            //If the row is null (nothing allocated to it yet so no data inside of it), it will print None
            else if (amc_[row] == NULL)
            {
                printf("None\n");
            }

            //If the row selected is a viable row and does have data in it, the program continues to this else block
            else
            {

                //Calls the get owner function
                char* tempChar = get_owner(amc_, row, seat);

                //Decides which output to print based on whatever get_owner returns
                if (tempChar != NULL)
                {
                    printf("%s\n", tempChar);
                }
                else
                {
                    printf("None\n");
                }

            }

        }

        //If the user wants types EXIT, this block activates
        else if (strcmp(BuyOrLookupOrExit, Exit) == 0)
        {

            //Nested for loop to make sure every piece of data gets freed
            for (int i = 0; i < MAXROWS; i++)
            {
                if (amc_[i] == NULL)
                {
                    continue;
                }
                for (int j = 0; j < amc_[i]->cur_size; j++)
                {
                    free_order(amc_[i]->list_orders[j]);
                }
                free_row(amc_[i]);

            }

            //Then frees amc_ and exits with code 0
            free(amc_);
            exit(0);
        }

        //If the user does not type in BUY, LOOKUP, or QUIT, this prints 
        else
        {
            printf("FAILURE\n");
        }

    }
    return 0;
}