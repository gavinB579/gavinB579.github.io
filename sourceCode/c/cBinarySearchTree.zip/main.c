/* COP 3502C Assignment 5
This program is written by: Gavin Bates*/

//All of the libraries, warnings, and defines used
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define MAXLEN 25

//Mandatory structs
typedef struct customer
{
    char name[MAXLEN + 1];
    int points;
}customer;

typedef struct bstnode
{
    customer* custPtr;
    int size;
    struct bstnode* left;
    struct bstnode* right;
}bstnode;

//List of functions
void sizeAdjustment(bstnode* par, bstnode* root);
bstnode* deleteNode(bstnode* name, bstnode* root);
bstnode* minVal(bstnode* root);
int isLeaf(bstnode* node);
int hasOnlyLeftChild(bstnode* node);
int hasOnlyRightChild(bstnode* node);
bstnode* findNode(bstnode* current_ptr, char name[]);
bstnode* parent(bstnode* root, bstnode* node);
void subtract(char name[], int points, bstnode* root);
void search(char name[], bstnode* curNode, int i);
bstnode* add(bstnode* root, bstnode* temp);
bstnode* createNode(char name[], int points);
int partition(customer** vals, int low, int high);
void quickSort(customer** numbers, int low, int high);
int main();

//deleteNode function
bstnode* deleteNode(bstnode* name, bstnode* root)
{
    //Creates 4 variables of type bstnode*
    bstnode* delnode, * new_del_node, * save_node, * par;
    //Creates a char called save_val that can save the name of the user
    char save_val[26] = "";

    //Sets delnode equal to name (which is the result of find node sent from main)
    delnode = name;

    //Finds the parent of delnode
    par = parent(root, delnode);

    //If delnode is a leaf node, then this happens
    if (isLeaf(delnode))
    {
        //If par is null on a leaf node, then the only node in the tree is the root
        if (par == NULL)
        {
            //Free root->custPtr, then root
            free(root->custPtr);
            free(root);
            //Return null
            return NULL;
        }
        //If the name stored in delnode is less than the parent node, it must be to the left of parent node
        if (strcmp(delnode->custPtr->name, par->custPtr->name) < 0)
        {
            //Free the appropriate memory
            free(par->left->custPtr);
            free(par->left);
            //Set par->left = null because that node is being deleted
            par->left = NULL;

            //Call sizeAdjustment to adjust the size of the bst
            sizeAdjustment(par, root);
        }
        //If the name stored in delnode is greater than the parent node, it must be to the right
        else if (strcmp(delnode->custPtr->name, par->custPtr->name) > 0)
        {
            //Free the appropriate memory
            free(par->right->custPtr);
            free(par->right);
            //Set par->right = null because that node is being deleted
            par->right = NULL;
            //Call sizeAdjustment to adjust size of bst
            sizeAdjustment(par, root);
        }
        //Return root
        return root;
    }


    //This if block only activates if there is only a left child node
    if (hasOnlyLeftChild(delnode))
    {
        //If par is null on only left child, then that means there is a root and only a left side to the bst, no right side
        if (par == NULL)
        {
            //Save the left node of delnode
            save_node = delnode->left;
            //Free the appropriate memory
            free(delnode->custPtr);
            free(delnode);
            return save_node;
        }
        //If delnode is less than the parent, it must be to the left of parent
        if (strcmp(delnode->custPtr->name, par->custPtr->name) < 0)
        {
            //Save the node to the left of parent and set par->left to par->left->left
            save_node = par->left;
            par->left = par->left->left;
            //Free the appropriate memory
            free(save_node->custPtr);
            free(save_node);
            //Call sizeAdjustment to adjust the size of the bst
            sizeAdjustment(par, root);
        }
        //If the delnode is greater than the parent node, it must be to the right of the parent node
        else if (strcmp(delnode->custPtr->name, par->custPtr->name) > 0)
        {
            //Save par->right, and set par->right = par->right->right
            save_node = par->right;
            par->right = par->right->left;
            //Free the appropriate memory
            free(save_node->custPtr);
            free(save_node);
            //Call sizeAdjustment to adjust the size of the bst
            sizeAdjustment(par, root);
        }
        return root;
    }

    //If delnode only has a right child, do this
    if (hasOnlyRightChild(delnode))
    {
        //If par == null, then there is only a right side to the bst
        if (par == NULL)
        {
            //Save the node to the right of delnode
            save_node = delnode->right;
            //Free the appropriate memory
            free(delnode->custPtr);
            free(delnode);
            return save_node;
        }
        //If delnode is less than the parent node, it must be to the left of parent node
        if (strcmp(delnode->custPtr->name, par->custPtr->name) < 0)
        {
            //Save par->left, and set par->left = par->left->left
            save_node = par->left;
            par->left = par->left->right;
            //Free the appropriate memory
            free(save_node->custPtr);
            free(save_node);
            //Call sizeAdjustment to adjust the size of the bst
            sizeAdjustment(par, root);
        }
        //If delnode is greater than the parent node, then it must be to the right
        else if (strcmp(delnode->custPtr->name, par->custPtr->name) > 0)
        {
            //Save par->right and set par->right = par->right->right
            save_node = par->right;
            par->right = par->right->right;
            //Free the appropriate memory
            free(save_node->custPtr);
            free(save_node);
            //Call sizeAdjustment to adjust the size of the bst
            sizeAdjustment(par, root);
        }
        return root;
    }
    //If it reaches this point, then the parent node must have 2 children
    //Call the minVal function. This function gets the largest value on the left-hand side of the bst
    new_del_node = minVal(delnode->left);
    //Save the values before you delete the node
    strcpy(save_val, new_del_node->custPtr->name);
    int save_points = 0;
    save_points = new_del_node->custPtr->points;

    //Recursively call the deleteNode function, sending it the new node you want to delete
    deleteNode(new_del_node, root);

    //Save the values copied in the right location
    strcpy(delnode->custPtr->name, save_val);
    delnode->custPtr->points = save_points;
    return root;
}

//This is the minVal function. It gets the largest value to the left-hand side of the bst. It is only called if the parent node has two children.
bstnode* minVal(bstnode* root)
{
    if (root->right == NULL)
    {
        return root;
    }
    else
    {
        return minVal(root->right);
    }
}

//This is the isLeaf function. It checks if the current node is a leaf node (does not have any children)
int isLeaf(bstnode* node)
{
    return (node->left == NULL && node->right == NULL);
}

//This is the hasOnlyLeftChild function. It checks if the current node has only a left child.
int hasOnlyLeftChild(bstnode* node)
{
    return(node->left != NULL && node->right == NULL);
}

//This is the hasOnlyRightChild function. It checks if the current node has only a right child
int hasOnlyRightChild(bstnode* node)
{
    return(node->left == NULL && node->right != NULL);
}

//This is the findNode function. It is used to find a node in a bst. 
bstnode* findNode(bstnode* current_ptr, char name[])
{
    //Base case
    if (current_ptr != NULL)
    {
        //If the name and current pointer are exaclty the same, you've found the node and return it
        if (strcmp(current_ptr->custPtr->name, name) == 0)
        {
            return current_ptr;
        }
        //If the name is less than the current node, it must be to the left of the current node, so it recursively calls this function while setting
        //the current node equal to the node to the left of the current node
        else if (strcmp(name, current_ptr->custPtr->name) < 0)
        {
            return findNode(current_ptr->left, name);
        }
        //If the name is greater than the current node, it must be to the right of the current node, so it recursively calls this function while setting
        //the current node equal to the node to the right of the current node
        else if (strcmp(name, current_ptr->custPtr->name) > 0)
        {
            return findNode(current_ptr->right, name);
        }
    }
    //Catchall
    return NULL;
}

//This is the parent function. It finds the parent node of the delnode
bstnode* parent(bstnode* root, bstnode* node)
{
    //Basecase
    if (root == NULL || root == node)
    {
        return NULL;
    }
    //Other basecase
    if (root->left == node || root->right == node)
    {
        return root;
    }
    //If the node is smaller than the root node, go to the left.
    if (strcmp(node->custPtr->name, root->custPtr->name) < 0)
    {
        return parent(root->left, node);
    }
    //If the node is greater than the root node, go to the right
    else if (strcmp(node->custPtr->name, root->custPtr->name) > 0)
    {
        return parent(root->right, node);
    }
    //Catchall
    return NULL;
}

//This is the subtract function. It subtracts points based on the user inputs
void subtract(char name[], int points, bstnode* root)
{
    //Basecase
    if (root != NULL)
    {
        //If the name is directly equal to the node, you've found the node and are good to delete the points.
        if (strcmp(name, root->custPtr->name) == 0)
        {
            //If the points the user wants to delete is greater than the points the node has, it will set the nodes' points = 0.
            if (points > root->custPtr->points)
            {
                root->custPtr->points = 0;
                printf("%s %d\n", name, 0);
            }
            //Else the points the node has must be greater than the points the user wants to delete, so it is safe to delete the user input without going negative.
            else
            {
                root->custPtr->points -= points;
                printf("%s %d\n", name, root->custPtr->points);
            }
        }
        //If the name is smaller than the current node, it must be to the left of the current node.
        else if (strcmp(name, root->custPtr->name) < 0)
        {
            //If the root->left is not null, it is safe to look to the left.
            if (root->left != NULL)
            {
                subtract(name, points, root->left);
            }
            //If the name is smaller than the current node but there is nothing to the left, then the name must not exist
            else
            {
                printf("%s not found\n", name);
            }
        }
        //If the name is greater than the current node, it must be to the right of the current node
        else if (strcmp(name, root->custPtr->name) > 0)
        {
            //If the root->right is not null, it is safe to look to the right
            if (root->right != NULL)
            {
                subtract(name, points, root->right);
            }
            //If the name is greater than the current node but there is nothing to the right, then the name must not exist
            else
            {
                printf("%s not found\n", name);
            }
        }
    }
}

//This is the search function. It searches for a node in the bst and outputs the name, points, and the depth if the name exists.
void search(char name[], bstnode* curNode, int i)
{
    //Basecase
    if (curNode != NULL)
    {
        //If the name and the curNode is directly equal, the node has been found.
        if (strcmp(name, curNode->custPtr->name) == 0)
        {
            printf("%s %d %d\n", curNode->custPtr->name, curNode->custPtr->points, i);
        }
        //If the name is smaller than the curNode, it must be to the left of the curNode.
        else if (strcmp(name, curNode->custPtr->name) < 0)
        {
            //This recursively calls the function while setting curNode equal to the node to the left. It also increases the depth counter (i)
            search(name, curNode->left, i + 1);
        }
        //If the name is greater than the curNode, it must be to the right of the curNode
        else if (strcmp(name, curNode->custPtr->name) > 0)
        {
            //This recursively calls the function while setting curNode equal to the node to the right. It also increases the depth counter (i)
            search(name, curNode->right, i + 1);    
        }
    }
    //The name must not exist in the bst
    else
    {
        printf("%s not found\n", name);
    }
}

//This is the add function. It is responsible for adding a temporary node into the bst.
bstnode* add(bstnode* root, bstnode* temp)
{
    //Basecase. If the root is null then there is nothing in the bst yet, so the temp node can be the root.
    if (root == NULL)
    {
        return temp;
    }
    //Other basecase
    else if (root != NULL)
    {
        //This increases the size for every node as it recurses.
        root->size++;
        //If the root is less than the tempNode, the temp node must be greater than the root, so go to the right.
        if (strcmp(root->custPtr->name, temp->custPtr->name) < 0)
        {
            //If the root->right is not null, then there is something to the right.
            if (root->right != NULL)
            {
                //This recurses to the right.
                root->right = add(root->right, temp);
            }
            //Otherwise, there is no node to the right and it is safe to add the temp node there.
            else
            {
                root->right = temp;
            }
        }
        //If the root is greater than the tempNode, the temp node must be less than the root, so go to the left.
        else if (strcmp(root->custPtr->name, temp->custPtr->name) > 0)
        {
            //If the root->left is not null, then there is something to the left.
            if (root->left != NULL)
            {
                //This recurses to the left.
                root->left = add(root->left, temp);
            }
            //Otherwise, there is no node to the left and it is safe to add the temp node there.
            else
            {
                root->left = temp;
            }
        }
        //Catchall
        return root;
    }
}

//This creates a node and mallocs the appropriate space.
bstnode* createNode(char name[], int points)
{
    bstnode* temp = (bstnode*)malloc(sizeof(bstnode));
    temp->custPtr = (customer*)malloc(sizeof(customer));
    strcpy(temp->custPtr->name, name);
    temp->custPtr->points = points;
    //Size starts at 1
    temp->size = 1;
    //Sets the left and right nodes to null
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}

//This is the countSmaller function. It counts how many nodes in the bst are smaller than the user input name. The user input name does not have to exist in the bst for
//it to count how many smaller nodes there are.
void countSmaller(char name[], bstnode* root, int* pointer, int* counter)
{
    //Basecase
    if (root != NULL)
    {
        //The name and node name are equal
        if (strcmp(name, root->custPtr->name) == 0)
        {
            //If counter is not 0, then it means the root is not being compared to name and it is some other node being compared.
            if (*counter != 0)
            {
                //Anything to the left WILL be smaller than the current node
                if (root->left != NULL)
                {
                    *pointer = *pointer + root->left->size;
                    return;
                }
                else
                {
                    //Otherwise, root->left is null so we have to find the size some other way.
                    //If root->right is not null, we can use that to find the size.
                    //Anything to the right MUST be smaller than the current node, so we can take the current *pointer size
                    // and add it to the current nodes' size - everything on the right, minus 1 to disregard the current node.
                    if (root->right != NULL)
                    {
                        *pointer = *pointer + root->size - root->right->size - 1;
                    }
                    //Else, both sides are null so return.
                    else
                    {
                        return;
                    }
                }
            }
            //Comparing the root node to the name. This only occurs if the comparison is between the root node and the name.
            else
            {
                //Counter increases to show that the next iteration if possible will no longer be the root of the bst.
                *counter = *counter + 1;
                //If the left side is NOT null (remember this is the root node being compared), everything to the left of the current node (root) MUST be greater.
                if (root->left != NULL)
                {
                    *pointer = root->left->size;
                }
                //There must not be a left side to the bst and everything to the right MUST be smaller than the current node (root).
                else
                {
                    return;
                }
                //Can't be anything smaller on the right hand side
            }
        }
        //The name is less than the name at the current node
        else if (strcmp(name, root->custPtr->name) < 0)
        {
            //Increase the counter so the comparison is no longer at the root node after this iteration
            *counter = *counter + 1;
            //As long as something exists to the left side of the bst, recurse to the left.
            if (root->left != NULL)
            {
                countSmaller(name, root->left, pointer, counter);
            }
            //Otherwise, there can be no farther nodes to the left
            else
            {
                return;
            }
        }
        //The name is greater than the name at the current node
        else if (strcmp(name, root->custPtr->name) > 0)
        {
            //This checks if the comparison is with the root node. If counter != 0, then the node being compared is NOT the root.
            if (*counter != 0)
            {
                //If there is a node to the right of the current node, take everything to the left of the current node and add it on to the *pointer.
                //Then recurse right.
                if (root->right != NULL)
                {
                    *pointer = *pointer + root->size - root->right->size;
                    countSmaller(name, root->right, pointer, counter);
                }
                //If the root->right IS null but root->left is NOT null, then do a different equation to get size. DO NOT recurse as there is nothing to the right.
                else if (root->right == NULL && root->left != NULL)
                {
                    *pointer = *pointer + root->left->size + 1;
                }
                //Otherwise, both root->right and root->left are null, so add the current node to the *pointer counter and return.
                else
                {
                    *pointer = *pointer + 1;
                    return;
                }

            }
            //We are comparing the root node to the name
            else
            {
                //Since name is greater than the root node, everything to the left of the root node including the root node must be smaller than the name.
                *counter = *counter + 1;
                //If nodes exist to the right, recurse right after adding everything on the left side to the *pointer.
                if (root->right != NULL)
                {
                    *pointer = root->size - root->right->size;
                    countSmaller(name, root->right, pointer, counter);
                }
                //Otherwise, there is no right side to the bst (we are at the root of the bst and root->right == NULL) so the entire size of the bst is smaller.
                else
                {
                    *pointer = *pointer + root->size;
                    return;
                }

            }
        }
    }
   
}

//This is the fillArray function. It fills the array of with pointers to each customer in the bst.
void fillArray(customer** array, bstnode* root,int* pointer)
{
    //Basecase
    if (root != NULL)
    {
        //Adds the information and increases the counter.
        array[*pointer] = root->custPtr;
        *pointer = *pointer + 1;
        //Recurses through every existing node in the bst.
        fillArray(array, root->left, pointer);
        fillArray(array, root->right, pointer);
    }
}

//This is the swap function. It swaps customer* a with customer* b.
void swap(customer* a, customer* b)
{
   // printf("swap function\n");
    customer t = *a;
    *a = *b;
    *b = t;
}

//This is the partition function. It creates a partition and swaps values when necessary.
int partition(customer** vals, int low, int high)
{
    //This creates a random pivot point within the bounds of the pointer array.
    int i = low + rand() % (high - low + 1);

    //This swaps values so the pivot is on the far left of the array.
    swap(vals[low], vals[i]);

    //This sets the pivot point location equal to lowpos.
    int lowpos = low;

    //Increase the counter so it starts at the location directly next to the pivot point, so the pivot point is not included until it needs to be.
    low++;

    //While the low counter does not cross the high counter, this happens.
    while (low <= high)
    {
        //This checks that low and high do not cross, while also checking if the points at the low counter are less than or equal to the points at the pivot.
        while (low <= high && vals[low]->points <= vals[lowpos]->points)
        {
            //If the value of the points at the low counter and the points at the pivot are the same, we need to sort alphabetically.
            if (vals[low]->points == vals[lowpos]->points)
            {
                //If the name at the low counter is greater than the name at the pivot point, increase the low counter.
                if (strcmp(vals[low]->name, vals[lowpos]->name) > 0)
                {
                    low++;
                }
                //Otherwise, a swap must occur for them to be sorted alphabetically.
                else
                {
                    swap(vals[low], vals[lowpos]);
                }
            }
            //Increase the low counter.
            else
            {
                low++;
            }
        }
        //While the high counter does not cross with the low counter and while the points at the high counter are greater than the points at the low counter, take away from the high counter.
        while (high >= low && vals[high]->points > vals[lowpos]->points)
        {
            high--;
        }
        //If low is less than high, swap low and high values.
        if (low < high)
        {
            swap(vals[low], vals[high]);
        }
    }
    //Then swap the pivot with the high value.
    swap(vals[lowpos], vals[high]);

    //Return high
    return high;
}

//This is the quicksort function. It is responsible for controlling which part of quicksort activates when.
void quickSort(customer** numbers, int low, int high)
{
    if (low < high)
    {
        int split = partition(numbers, low, high);
        quickSort(numbers, low, split - 1);
        quickSort(numbers, split + 1, high);
    }
}

//This is the freeFunc. It frees any left over memory still in use before the program stops.
void freeFunc(bstnode* root)
{
    if (root != NULL)
    {
        //Frees each customer.
        free(root->custPtr);
        //Recurses through the entire bst.
        freeFunc(root->left);
        freeFunc(root->right);
        //Frees the node.
        free(root);
    }
}

//This is the sizeAdjustment function. It adjusts the size during the deleteNode function.
void sizeAdjustment(bstnode* par, bstnode* root)
{
    //Basecase
    if (par == NULL)
    {
        return;
    }
    else if (par != NULL && par != root)
    {
        //Decreases size 
        par->size--;
        //Calls parent of the current parent.
        par = parent(root, par);
        //Recursively calls this function until one of the cases is reached.
        sizeAdjustment(par, root);
        return;
    }
    else
    {
        //Catchall
        par->size--;
        return;
    }
}

//This is the main function. It is the hub of the program.
int main()
{
    //Two vars of type bstnode*
    bstnode* root = NULL, * temp = NULL;

    //Variable used for number of inputs.
    int numOfInputs = 0;

    //Takes the first line for user input. It is how many commands the user will use total. Cannot be more than 300,000.
    scanf("%d", &numOfInputs);
    if (numOfInputs > 300000)
    {
        return 0;
    }
    //This loops until the counter (i) reaches the number of inputs the user wants.
    for (int i = 0; i < numOfInputs; i++)
    {
        //Temp variables reset with every loop.
        char whatToDo[26] = "";
        char name[26] = "";
        int points;

        //Scans what the user wants to do. Options are: add, sub, del, search, count_smaller.
        scanf("%s", whatToDo);

        //If the user wants to add, this if block happens.
        if (strcmp(whatToDo, "add") == 0)
        {
            //Scans for a name and points.
            scanf("%s %d", name, &points);
            //Creates a temp node of type bstnode*.
            bstnode* tempNode;
            //This looks to the see if the node the user wants already exists.
            tempNode = findNode(root, name);
            //If the node does not exist, it creates a new node and inserts it into the bst.
            if (tempNode == NULL)
            {
                temp = createNode(name, points);
                root = add(root, temp);
                printf("%s %d\n", name, points);
            }
            //Otherwise, the node already exists and it just adds the points onto the existing node without creating a duplicate.
            else
            {
                tempNode->custPtr->points += points;
                printf("%s %d\n", name, tempNode->custPtr->points);
            }
        }
        //If the user wants to subtract, this if block activates.
        else if (strcmp(whatToDo, "sub") == 0)
        {
            //Scans for the name they want to subtract from and how many points they want to subtract, then calls the subtract function.
            scanf("%s %d", name, &points);
            subtract(name, points, root);
        }
        //If the user wants to delete, this if block activates.
        else if (strcmp(whatToDo, "del") == 0)
        {
            //Scans the name of the node the user wants to delete.
            scanf("%s", name);
            //Creates a temp node of type bstnode* and sets it equal to NULL.
            bstnode* tempNode = NULL;
            //Searches for the node of the person the user wants to delete.
            tempNode = findNode(root, name);
            //If the node does not exist, that name is not in the bst and cannot be deleted.
            if (tempNode == NULL)
            {
                printf("%s not found\n", name);
            }
            //Otherwise, the person exists in the bst and is deleted.
            else
            {
                root = deleteNode(tempNode, root);
                printf("%s deleted\n", name);
            }
        }
        //If the user wants to search, this if block activates.
        else if (strcmp(whatToDo, "search") == 0)
        {
            //This scans the name of the person the user wants to search for.
            scanf("%s", name);
            search(name, root, 0);
        }
        //If the user wants to count_smaller, this if block activates.
        else if (strcmp(whatToDo, "count_smaller") == 0)
        {
            //This scans the name of the person the user wants to count smaller.
            scanf("%s", name);
            //Two temp variables.
            int tempResult = 0;
            int counter = 0;
            //Calls the count smaller function.
            countSmaller(name, root, &tempResult, &counter);
            printf("%d\n", tempResult);
        }

    }
    //Once all inputs have been completed, this happens.
    //This creates a malloc for an array that will hold points to the customers.
    customer** pointerArr = malloc((root->size) * sizeof(customer));
    int tempPointer = 0;
    //This fills that array with the customer pointers.
    fillArray(pointerArr, root, &tempPointer);
    //This quicksorts the array by point value and then by name if the point value is the same.
    quickSort(pointerArr, 0, tempPointer - 1);

    //This prints every value in the array. It is in reverse order because quicksort sorted it smallest to largest and it is supposed to be largest to smallest.
    for (int i = tempPointer - 1; i >= 0; i--)
    {
        printf("%s %d\n", pointerArr[i]->name, pointerArr[i]->points);
    }
    //This frees all of the remaining malloced memory.
    free(pointerArr);
    freeFunc(root);

    return 0;
}