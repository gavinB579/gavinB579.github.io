/*COP 3502C Assignment 6
This program is written by: Gavin Bates*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

//Global variables
int totalCash;
int totalComplexity;

#define MAXSTLEN 24
#define TABLESIZE 300007


//Structs
typedef struct item {
	char name[MAXSTLEN + 1]; //the key
	int qty; //for quantity
	int saleprice;
} item;

typedef struct chainNode {
	item* itemPtr;
	struct chainNode* next;
} chainNode;

typedef struct hashTable {
	chainNode** lists;
	int size;
} hashTable;

//SellTable function. This is resposible for calculating the quantity and totalCash on the sell command. It also adjusts totalComplexity.
void sellTable(chainNode* temp, int quantity)
{
	//Increases totalComplexity.
	totalComplexity += 1;

	//If the quantity the user wants to subtract is greater than the quantity stored, set it equal to 0 and adjust everything accordingly
	if (quantity > temp->itemPtr->qty)
	{
		totalCash += temp->itemPtr->saleprice * temp->itemPtr->qty;
		temp->itemPtr->qty = 0;
	}
	//Else the quantity must be less than the quantity stored
	else
	{
		totalCash += temp->itemPtr->saleprice * quantity;
		temp->itemPtr->qty -= quantity;
	}
	printf("%s %d %d\n", temp->itemPtr->name, temp->itemPtr->qty, totalCash);
}

//changePriceTable function. Adjusts the price of the item as well as totalComplexity.
void changePriceTable(chainNode* temp, int new_price)
{
	totalComplexity += 1;
	temp->itemPtr->saleprice = new_price;
}

//initTable function. Initializes the hashTable.
void initTable(hashTable* h)
{
	int i;

	for (i = 0; i < TABLESIZE; i++)
	{
		h->lists[i] = NULL;
	}
}

//insert_front function. Inserts the node at the front of a list.
chainNode* insert_front(chainNode* front, char itemName[], chainNode* root)
{
	root->next = front;
	return root;
}

//Search function. This is responsible for searching for the node and adjusting the necessary information.
int search(chainNode* front, char itemName[], chainNode* root)
{
	//Temp counter variable
	int tempCounter = 0;

	//While the ll is not null this loop will loop.
	while (front != NULL)
	{
		//Increase the totalComplexity and tempCounter counters.
		totalComplexity += 1;
		tempCounter += 1;

		//If the node has been found with the item name, this if will activate.
		if (strcmp(front->itemPtr->name, itemName) == 0)
		{
			//Adjusts the qty
			front->itemPtr->qty += root->itemPtr->qty;
			printf("%s %d %d\n", front->itemPtr->name, front->itemPtr->qty, totalCash);
			return 1;
		}
		//Else go to the next node
		front = front->next;
	}

	//If it reaches here, the item was not found in the ll. That means that everything added to totalComplexity doesn't matter because the node did not exist. Reset the complexity to before this function.
	totalComplexity -= tempCounter;
	return 0;
}

//This is the searchTable function. It finds the hashval of the itemName and calls the search function.
int searchTable(hashTable* table, char itemName[], chainNode* root)
{
	int hashval = hashfunction(itemName, table->size);
	return search(table->lists[hashval], itemName, root);
}

//This is the hash function. It finds the hashval of the given word with the size of the hash table.
int hashfunction(char* word, int size)
{
	int len = strlen(word);
	int res = 0;
	for (int i = 0; i < len; i++)
	{
		res = (1151 * res + (word[i] - 'a')) % size;
	}
	return res;
}

//This creates a node.
chainNode* createNode(chainNode* root, char itemName[], int quantity, int price)
{
	chainNode* t = root;
	//This mallocs all of the space and saving the information.
	chainNode* temp = (chainNode*)malloc(sizeof(chainNode));
	temp->itemPtr = (item*)malloc(sizeof(item));
	strcpy(temp->itemPtr->name, itemName);
	temp->itemPtr->qty = quantity;
	temp->itemPtr->saleprice = price;

	//Sets the next node to null
	temp->next = NULL;
	return temp;
}

//This is the freeFunc. It gets called at the end of the program to free the rest of the memory.
void freeFunc(hashTable* table)
{
	//Counter variable
	int i = 0;

	//This allows me to iterate through the entire hashTable.
	while (i < TABLESIZE)
	{
		//Check if there are any nodes in this hashTable element. If there are, temp variable is created to save the next node in the element. Free the current one and move lists[i] = temp (the next node).
		while (table->lists[i] != NULL)
		{
			chainNode* temp = table->lists[i]->next;
			free(table->lists[i]->itemPtr);
			free(table->lists[i]);
			table->lists[i] = temp;
		}
		//Increasing the counter
		i++;
	}
	//Freeing the memory.
	free(table->lists);
	free(table);

}

//This is the main function. It is the hub of this program.
int main()
{
	//Create/malloc the necessary variables.
	chainNode* root = NULL;
	hashTable* table = (hashTable*)malloc(sizeof(hashTable) * TABLESIZE);
	table->lists = (chainNode**)malloc(sizeof(chainNode*) * TABLESIZE);
	table->size = TABLESIZE;

	//This sets the initial cash equal to $100,000
	totalCash = 100000;

	//This takes in the user input for the total number of commands.
	int numOfCommands = 0;
	scanf("%d", &numOfCommands);

	//This initializes the hash table.
	initTable(table);
	
	//This for loop loops until the total number of commands dictated by the user is complete
	for (int i = 0; i < numOfCommands; i++)
	{
		//This scans if the user wants to buy sell or change the price.
		char buySellChange[25] = "";
		scanf("%s", buySellChange);

		char item[MAXSTLEN + 1] = "";
		int quantity = 0;
		int price = 0;
		
		//If the user wants to buy, this if activates
		if (strcmp(buySellChange, "buy") == 0)
		{
			//This scans the necessary information from the user
			scanf("%s %d %d", item, &quantity, &price);
			int totalPrice = price / quantity;
			//This adjusts the totalCash
			totalCash -= price;
			
			//This creates a node
			root = createNode(root, item, quantity, totalPrice);
			//This searches to see if the information exists. If it does, it will add to the quantity
			int searchRes = searchTable(table, item, root);
			//If the information does not exist, this happens. It finds the hashval and inserts it into the front.
			if (searchRes == 0)
			{
				int hashval = hashfunction(item, table->size);
				table->lists[hashval] = insert_front(table->lists[hashval], item, root);
				printf("%s %d %d\n", root->itemPtr->name, root->itemPtr->qty, totalCash);
				chainNode* tempNode = table->lists[hashval];
				//As in the instructions, if this if block activates the node must not exist so this while loop counts every node in the ll AFTER the insertion.
				while (tempNode != NULL)
				{
					totalComplexity += 1;
					tempNode = tempNode->next;
				}
			}
			//If searchRes returns 1, then the node already exists, so free the unused memory created.
			else if (searchRes == 1)
			{
				free(root->itemPtr);
				free(root);
			}
		}
		//This is the sell if statement.
		else if (strcmp(buySellChange, "sell") == 0)
		{
			//This scans the necessary information.
			scanf("%s %d", item, &quantity);

			//This finds the hashval and finds the node it is in.
			int hashval = hashfunction(item, table->size);
			chainNode* temp = table->lists[hashval];
			//For sell, the item is guaranteed to be there. That means that total complexity gets added until the loop reaches the kth node.
			while (strcmp(item, temp->itemPtr->name) != 0)
			{
				totalComplexity += 1;
				temp = temp->next;
			}
			//Once we have the node, send it to be adjusted
			sellTable(temp, quantity);
		}
		//This is the change price statement
		else if (strcmp(buySellChange, "change_price") == 0)
		{
			//This scans the necessary information
			int new_price = 0;
			scanf("%s %d", item, &new_price);

			//This finds the hashval and finds the node it is in.
			int hashval = hashfunction(item, table->size);
			chainNode* temp = table->lists[hashval];
			//For change price, the item is guaranteed to be there. That means that total complexity gets added until the loop reaches the kth node.
			while (strcmp(item, temp->itemPtr->name) != 0)
			{
				totalComplexity += 1;
				temp = temp->next;
			}
			//Once we have the node, send it to be adjusted
			changePriceTable(temp, new_price);
		}
		//If the command is not recognised, it ends the program.
		else
		{
			exit(0);
		}
	}
	//This prints the end totalCash and totalComplexity.
	printf("%d\n%d\n", totalCash, totalComplexity);

	//freeFunc is called to free the rest of the memory.
	freeFunc(table);
	
	return 0;
}