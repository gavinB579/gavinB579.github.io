<?php
$server = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($server, $username, $password, "CIS4004Project3");
session_start();

$error = "";

if(isset($_POST['register']))
{
    $createUsername = $_POST['username'];
    $createPassword = $_POST['password'];
    $optionalCode = $_POST['optionalCode'];

    //ChatGPT helped with this invalid character detection.
    if(preg_match("/[^a-zA-Z0-9_\-\.]/", $createUsername) || preg_match("/[^a-zA-Z0-9_\-\.]/", $createPassword))
    {
        $error = "invalChar";
    }
    else if($optionalCode != "ADMIN2025" && $optionalCode != "")
    {
        $error = "invalCode";
    }
    else
    {
        $error = "";

        $result = $conn->query("SELECT Count(*) as tempNum FROM `user` WHERE usr_username = '$createUsername'");
        $userExistCheck = $result->fetch_assoc();

        if($userExistCheck["tempNum"] == 0)
        {
            $conn->query("CALL addUser('$createUsername', '$createPassword', '$optionalCode')");

            
            $userCredentials = $conn->query("SELECT usr_id, `role`, tm_id FROM `user` WHERE usr_username = '$createUsername' AND usr_password = '$createPassword' ");
            $userCredentialsResult = $userCredentials->fetch_assoc();

            $_SESSION['user_ID'] = $userCredentialsResult["usr_id"];
            $_SESSION['user_Role'] = $userCredentialsResult["role"];
            $_SESSION['user_Team'] = $userCredentialsResult["tm_id"];

            if($_SESSION['user_Role'] == "administrator")
            {
                header("Location: AdminPage.php");
                exit();
            }
            else
            {
                header("Location: SpectatorDashboard.php");
                exit();
            }
        }
        else
        {
            $error = "invalUsername";
        }
    }
}

//Excludes admins from the count. 
$result = $conn->query("SELECT Count(*) as TheCount FROM `user` WHERE `role` = 'user'");
?>

<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="index.css"> </head>
        <body class="UserHandlingBody">
            <div class="UserHandlingBox">
                <h1>Register</h1>
                    <?php 
                        if($error == "invalChar") 
                        {
                           echo "<p style='color:red;'> Invalid character(s). Please try again. </p>";
                        }
                        else if($error == "invalCode")
                        {
                            echo "<p style='color:red;'> Invalid code. Please try again. </p>";
                        }
                        else if($error == "invalUsername")
                        {
                            echo "<p style='color:red;'> Username already taken. Please try again. </p>";
                        }
                    ?>
                    <form method="POST">
                        <input
                            type="username"
                            name="username"
                            placeholder="Username"
                            required
                        />
                        <input
                            type="password"
                            name="password"
                            placeholder="Password"
                            required
                        />
                        <input
                            type="optionalCode"
                            name="optionalCode"
                            placeholder="Optional Code"
                        />
                        <button type="submit" class="blueButton" name="register">Create Account</button>
                        <p class="Login">Already have an account? <a href= "index.php">Login</a></p>
                        <?php
                            //Excludes admins
                            $row = $result->fetch_assoc();
                            echo '<p>Total Players Online: ' . $row["TheCount"] . '</p>'
                        ?>
                    </form>
            </div>
        </body>
</html>