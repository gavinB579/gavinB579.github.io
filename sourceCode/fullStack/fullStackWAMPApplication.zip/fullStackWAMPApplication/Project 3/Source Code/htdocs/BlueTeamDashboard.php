<?php
$server = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($server, $username, $password, "CIS4004Project3");
session_start();

if($_SESSION['user_Role'] != "administrator" && $_SESSION['user_Team'] != 3)
{
    session_destroy();
    header("Location: index.php");
    exit();
}



$result = $conn->query("SELECT * FROM user WHERE tm_id = 3 AND `role` = 'user'");
?>


<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="index.css"> </head>
        <body class="DashboardBodyBlueTeam">
            <div class="UserHandlingBox">
            <h1> Blue Team </h1>
                <?php
                    echo 
                        "<table border='1'>
                            <tr>
                                <th> ID </th>
                                <th> Username </th>
                            </tr>";
                    while($user = $result->fetch_assoc())
                        echo
                            "<tr>
                                <td> {$user['usr_id']} </td>
                                <td> {$user['usr_username']} </td>
                            </tr>"
                ?>
            </div>
        </body>
</html>