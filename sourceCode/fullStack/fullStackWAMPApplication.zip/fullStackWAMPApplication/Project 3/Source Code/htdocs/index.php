<?php
$server = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($server, $username, $password, "CIS4004Project3");
session_start();

$error = "";
if (isset($_POST['login']))
{
    $loginUsername = $_POST['username'];
    $loginPassword = $_POST['password'];

    //ChatGPT helped with this invalid character detection.
    if(preg_match("/[^a-zA-Z0-9_\-\.]/", $loginUsername) || preg_match("/[^a-zA-Z0-9_\-\.]/", $loginPassword))
    {
        $error = "invalChar";
    }
    else
    {
        $result = $conn->query("SELECT Count(*) as tempNum FROM `user` WHERE usr_username = '$loginUsername' AND usr_password = '$loginPassword' ");
        $validUser = $result->fetch_assoc();

        if ($validUser["tempNum"] == 1)
        {
            $error = "";
            
            $userCredentials = $conn->query("SELECT usr_id, `role`, tm_id FROM `user` WHERE usr_username = '$loginUsername' AND usr_password = '$loginPassword' ");
            $userCredentialsResult = $userCredentials->fetch_assoc();

            $_SESSION['user_ID'] = $userCredentialsResult["usr_id"];
            $_SESSION['user_Role'] = $userCredentialsResult["role"];
            $_SESSION['user_Team'] = $userCredentialsResult["tm_id"];

            if($userCredentialsResult["role"] == "administrator")
            {
                header("Location: AdminPage.php");
                exit();
            }
            else if($userCredentialsResult["tm_id"] == 1)
            {
                header("Location: SpectatorDashboard.php");
                exit();
            }
            else if($userCredentialsResult["tm_id"] == 2)
            {
                header("Location: RedTeamDashboard.php");
                exit();
            }
            else if($userCredentialsResult["tm_id"] == 3)
            {
                header("Location: BlueTeamDashboard.php");
                exit();
            }
        }
        else
        {
            $error = "invalCred";
        }
    }
    
}

//Excludes admins from the count. 
$returnOnlinePlayers = $conn->query("SELECT Count(*) as TheCount FROM `user` WHERE `role` = 'user'");
?>

<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="index.css"> </head>
        <body class="UserHandlingBody">
            <div class="UserHandlingBox">
                <h1>Login</h1>
                    <?php 
                        if($error == "invalChar") 
                        {
                           echo "<p style='color:red;'> Invalid character(s). Please try again. </p>";
                        }
                        else if($error == "invalCred") 
                        {
                           echo "<p style='color:red;'> Invalid credentials. Please try again. </p>";
                        }
                    ?>
                    <form action="" method="POST">
                        <input
                            type="username"
                            name="username"
                            placeholder="Username"
                            required
                        />
                        <input
                            type="password"
                            name="password"
                            placeholder="Password"
                            required
                        />
                        <button type="submit" class="blueButton" name="login">Login</button>
                        <p class="Register">Not registered? <a href= "CreateAccount.php">Create an account</a></p>
                        <?php
                            //Excludes admins
                            $row = $returnOnlinePlayers->fetch_assoc();
                            echo '<p>Total Players Online: ' . $row["TheCount"] . '</p>'
                        ?>
                    </form>
            </div>
        </body>
</html>