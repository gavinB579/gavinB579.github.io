<?php
$server = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($server, $username, $password, "CIS4004Project3");
session_start();

if($_SESSION['user_Role'] != "administrator" && $_SESSION['user_Team'] != 1)
{
    session_destroy();
    header("Location: index.php");
    exit();
}


if(isset($_POST['redTeam']))
{
    $conn->query("CALL updateTeam('$_SESSION[user_ID]', 'redTeam')");
    $_SESSION['user_Team'] = 2;
    header("Location: RedTeamDashboard.php");
    exit();
}
else if(isset($_POST['blueTeam']))
{
    $conn->query("CALL updateTeam('$_SESSION[user_ID]', 'blueTeam')");
    $_SESSION['user_Team'] = 3;
    header("Location: BlueTeamDashboard.php");
    exit();
}


$result = $conn->query("SELECT * FROM user WHERE tm_id = 1 AND `role` = 'user'");
?>


<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="index.css"> </head>
        <body class="DashboardBodySpectator">
            <div class="UserHandlingBox">
                <h1>Which team would you like to join?</h1>
                    <h3> Be careful, as you can only choose once...</h3>
                    <form method="POST">
                        <button type="submit" class="redButton" name="redTeam">Red Team</button>
                        <button type="submit" class="blueButton" name="blueTeam">Blue Team</button>
                    </form>

                    <div style="height: 75px;"></div>

                    <h2> Spectator(s) </h2>
                <?php
                    echo 
                        "<table border='1'>
                            <tr>
                                <th> ID </th>
                                <th> Username </th>
                            </tr>";
                    while($user = $result->fetch_assoc())
                        echo
                            "<tr>
                                <td> {$user['usr_id']} </td>
                                <td> {$user['usr_username']} </td>
                            </tr>"
                ?>
            </div>
        </body>
</html>