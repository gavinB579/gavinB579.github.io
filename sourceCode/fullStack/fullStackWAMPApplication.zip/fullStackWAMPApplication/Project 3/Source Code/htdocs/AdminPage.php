<?php
$server = "localhost";
$username = "root";
$password = "root";
$conn = new mysqli($server, $username, $password, "CIS4004Project3");
session_start();


$error = "";

if ($_SESSION['user_Role'] != "administrator")
{
    session_destroy();
    header("Location: index.php");
    exit();
}

if(isset($_POST['deleteIDBtn']))
{
    $error = "";
    $userIDInput = $_POST['deleteID'];

    //ChatGPT helped with this invalid character detection.
    if(preg_match("/\D/", $userIDInput))
    {
        $error = "invalInput";
    }
    else if ($userIDInput ==  $_SESSION['user_ID'])
    {
        $error = "invalEdit";
    }
    else
    {
        $result = $conn->query("SELECT Count(*) as tempNum FROM `user` WHERE usr_id = '$userIDInput'");
        $userExistCheck = $result->fetch_assoc();

        if($userExistCheck["tempNum"] == 1)
        {
            $error = "";
            $conn->query("CALL deleteUser('$userIDInput')");
            header("Location: AdminPage.php");
            exit();
        }
        else
        {
            $error = "invalUser";
        }
    }
}

if(isset($_POST['updateIDBtn']))
{
    $error = "";
    $userIDInput2 = $_POST['updateID'];
    $teamOption = $_POST['teamOption'];

    //ChatGPT helped with this invalid character detection.
    if(preg_match("/\D/", $userIDInput2))
    {
        $error = "invalInput";
    }
    else if ($userIDInput2 == $_SESSION['user_ID'])
    {
        $error = "invalEdit";
    }
    else
    {
        $error = "";
        $result = $conn->query("SELECT Count(*) as tempNum FROM `user` WHERE usr_id = '$userIDInput2'");
        $userExistCheck = $result->fetch_assoc();

        if($userExistCheck["tempNum"] == 1)
        {
            if ($teamOption == "spectator")
            {
                $conn->query("CALL updateTeam('$userIDInput2', 'spectator')");
                header("Location: AdminPage.php");
                exit();
            }
            else if ($teamOption == "redTeam")
            {
                $conn->query("CALL updateTeam('$userIDInput2', 'redTeam')");
                header("Location: AdminPage.php");
                exit();
            }
            else if ($teamOption == "blueTeam")
            {
                $conn->query("CALL updateTeam('$userIDInput2', 'blueTeam')");
                header("Location: AdminPage.php");
                exit();
            }
        }
        else
        {
            $error = "invalUser";
        }
    }
}

if(isset($_POST['createUser']))
{
    $error = "";
    $createUsername = $_POST['username'];
    $createPassword = $_POST['password'];
    $userRole = $_POST['userRole'];

    //ChatGPT helped with this invalid character detection.
    if(preg_match("/[^a-zA-Z0-9_\-\.]/", $createUsername) || preg_match("/[^a-zA-Z0-9_\-\.]/", $createPassword))
    {
        $error = "invalChar";
    }
    else
    {
        $error = "";

        $result = $conn->query("SELECT Count(*) as tempNum FROM `user` WHERE usr_username = '$createUsername'");
        $userExistCheck = $result->fetch_assoc();

        if($userExistCheck["tempNum"] == 0)
        {
            if($userRole == "administrator")
            {
                $userRole = "ADMIN2025";
            }
            $conn->query("CALL addUser('$createUsername', '$createPassword', '$userRole')");

            header("Location: AdminPage.php");
            exit();
        }
        else
        {
            $error = "invalUsername";
        }
    }
}

$table = $conn->query("SELECT * FROM user");
?>

<!DOCTYPE html>
<html>
    <head> <link rel="stylesheet" href="index.css"> </head>
        <body class="UserHandlingBody">
            <div class="DashboardContent">
                <h1>Administration</h1>
                <h3> Team ID's: (1 = Spectator) (2 = Red Team) (3 = Blue Team) </h3>
                <?php 
                    if($error == "invalInput")
                    {
                        echo "<p style='color:red;'> Input must be numeric. Try again. </p>";
                    }
                    if($error == "invalEdit") 
                    {
                        echo "<p style='color:red;'> You cannot edit yourself. Try again. </p>";
                    }
                    else if($error == "invalUser")
                    {
                        echo "<p style='color:red;'> User not found. </p>";
                    }
                    else if($error == "invalChar")
                    {
                        echo "<p style='color:red;'> Invalid character(s). Please try again. </p>";
                    }
                    else if($error == "invalUsername")
                    {
                        echo "<p style='color:red;'> Username already taken. Please try again. </p>";
                    }                     
                ?>
                    <form method="POST" class="deleteButtonAdmin">

                        <h3> Delete User </h3>
                        <input
                            type="deleteID"
                            name="deleteID"
                            placeholder="ID to Delete"
                            required
                        />
                        <button type='submit' class='redButton' name='deleteIDBtn'>Delete</button>
                    </form>

                    <form method="POST" class="updateButtonAdmin">
                        <h3> Update User's Team </h3>
                        <input
                            type="updateID"
                            name="updateID"
                            placeholder="ID to Update"
                            required
                        />
                        <select name="teamOption">
                            <option value="spectator">Spectator</option>
                            <option value="redTeam"> Red Team </option>
                            <option value="blueTeam"> Blue Team </option>
                        </select>
                        <button type='submit' class='blueButton' name='updateIDBtn'>Update</button>
                    </form>

                    <form method="POST" class="createButtonAdmin">
                        <h3> Create User </h3>
                        <input
                            type="username"
                            name="username"
                            placeholder="Username"
                            required
                        />
                        <input
                            type="password"
                            name="password"
                            placeholder="Password"
                            required
                        />
                        <select name="userRole">
                            <option value="user">User</option>
                            <option value="administrator">Administrator</option>
                        </select>
                        <button type='submit' class='greenButton' name='createUser'>Submit</button>
                    </form>
                    
                    <div style="height: 75px;"></div>
                    
                    <div class="tableFormat">
                        <?php
                            echo 
                                "<table border='1'>
                                    <tr>
                                        <th> ID </th>
                                        <th> Username </th>
                                        <th> Password </th>
                                        <th> Team ID </th>
                                        <th> Role </th>
                                    </tr>";
                            while($user = $table->fetch_assoc())
                                echo
                                    "<tr>
                                        <td> {$user['usr_id']} </td>
                                        <td> {$user['usr_username']} </td>
                                        <td> {$user['usr_password']} </td>
                                        <td> {$user['tm_id']} </td>
                                        <td> {$user['role']} </td>
                                    </tr>"
                            ?>
                    </div>
            </div>
        </body>
</html>