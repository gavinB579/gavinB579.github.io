CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteUser`(
	IN userID int
)
BEGIN
	DELETE FROM user where usr_id = userID;
END