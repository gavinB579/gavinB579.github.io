CREATE DEFINER=`root`@`localhost` PROCEDURE `addUser`(
	IN createUsername VARCHAR(255),
    IN createPassword VARCHAR(255),
    IN optionalCode VARCHAR(255)
)
BEGIN
	IF optionalCode = 'ADMIN2025' THEN INSERT INTO user (usr_username, usr_password, `role`) VALUES (createUsername, createPassword, "administrator");
    ELSE INSERT INTO user (usr_username, usr_password) VALUES (createUsername, createPassword);
    END IF;
END