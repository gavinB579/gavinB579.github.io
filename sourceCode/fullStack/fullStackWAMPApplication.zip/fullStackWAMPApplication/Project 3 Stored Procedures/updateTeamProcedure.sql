CREATE DEFINER=`root`@`localhost` PROCEDURE `updateTeam`(
	IN userID int,
    IN teamName varchar(255)    
)
BEGIN
	IF teamName = 'redTeam' THEN UPDATE user SET tm_id = 2 WHERE usr_id = userID;
    ELSEIF teamName = 'blueTeam' THEN UPDATE user SET tm_id = 3 WHERE usr_id = userID;
    ELSE UPDATE user SET tm_id = 1 WHERE usr_id = userID;
    END IF;
END